package app;

import aula1.Cliente;
import aula1.Pagamento;
import aula1.Pessoa;
import aula1.VendaPrazo;
import aula1.Vendedor;

/**
 * @author udesc
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Vendedor vendedor = new Vendedor(102030, "Joãosinho", "985671233");
        Cliente cliente = new Cliente("012345678901", "Mariasinha", "UDESc", "912345678");
        
        //VendaVista venda = new VendaVista(vendedor, cliente, 12000, Pagamento.DEBITO);
        //venda.show();
        
        VendaPrazo prazo = new VendaPrazo(vendedor, cliente, 12000, 5, Pagamento.CREDITO);
        prazo.show();
        prazo.pagarParcela();
    }
    
}
