package aula1;

/**
 * @author udesc
 */
public class VendaVista {
    private Vendedor vendedor;
    private Cliente comprador;
    /**
     * Valor em centavos
     */
    private int valor;
    private Pagamento tipoPagamento;
    
    public VendaVista( Vendedor v, Cliente c, int valor, Pagamento p ){
        if( v==null )
            System.err.println("ERROR: Vendedor nulo!");
        this.vendedor = v;
        this.comprador = c;
        this.tipoPagamento = p;
        
        if( this.tipoPagamento == Pagamento.DINHEIRO )
            this.valor = (int) (valor * 0.95);
        else
            this.valor = valor;
    }
    
    /**
     * Exibe na tela os registros básicos da venda a vista
     */
    public void show(){
        if( comprador != null ){
            System.out.println("Cliente: "+comprador.getNome());
            System.out.println(" telefone: "+comprador.getTelefone());
        }
        else
            System.out.println("Cliente: (sem registro)");
        System.out.println("Vendedor: "+vendedor.getNome());
        System.out.printf("Valor: R$ %.2f\n", valor/100.0 );
        //System.out.println("Valor: R$ "+ valor/100.0 + "," + valor%100 );
        System.out.println("Tipo Pagamento: "+tipoPagamento);
    }
}
