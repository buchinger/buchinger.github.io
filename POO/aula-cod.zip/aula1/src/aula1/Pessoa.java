package aula1;

/**
 * @author udesc
 */
public class Pessoa {
    String nome;
    String telefone;
    
    public Pessoa(String nome, String telefone){
        this.nome = nome;
        this.telefone = telefone;
    }
    
    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * Documentação sobre o método...
     * @return retorna o telefone formatado como: 9 9876-5432
     */
    public String getTelefone() {
        // 998765432
        // 012345678 indice
        // 9 9876-5432
        return telefone.charAt(0)+" "+
                telefone.substring(1,5)+"-"+
                telefone.substring(5);
    }
}
