package aula1;

import aula1.Pessoa;

/**
 * @author udesc
 */
public class Cliente extends Pessoa {
    private String cpf;
    private String endereco;
    
    public Cliente(String cpf, String nome, String end, String tel){
        super( nome, tel );
        this.cpf = cpf;
        this.endereco = end;
    }

    
    /**
     * @return the cpf
     */
    public String getCpf() {
        return cpf;
    }

    /**
     * @return the endereco
     */
    public String getEndereco() {
        return endereco;
    }
}
