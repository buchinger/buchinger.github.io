package aula1;

/**
 * @author udesc
 */
public enum Pagamento {
    DINHEIRO(1), CREDITO(2), DEBITO(3);
    int id;
    
    Pagamento(int i){
        this.id = i;
    }
    
    public String toString(){
        if( id == 1 ) return "Dinheiro";
        else if( id == 2 ) return "Crédito";
        else return "Débito";
    }
}
