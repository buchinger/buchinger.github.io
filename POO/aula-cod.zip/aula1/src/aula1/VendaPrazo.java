package aula1;

/**
 * @author udesc
 */
public class VendaPrazo {
    private Vendedor vendedor;
    private Cliente comprador;
    /**
     * Valor em centavos
     */
    private int valor;
    private int valorParcela;
    private int numeroParcelas;
    private int parcelasPagas;
    private Pagamento tipoPagamento;
    
    public VendaPrazo( Vendedor v, Cliente c, int valor, int parcelas, Pagamento p ){
        if( v==null )
            System.err.println("ERROR: Vendedor nulo!");
        this.vendedor = v;
        this.comprador = c;
        this.tipoPagamento = p;
        this.numeroParcelas = parcelas;
        this.valor = (int) (valor * (1 + parcelas * 0.025));
        this.valorParcela = this.valor / numeroParcelas;
        this.parcelasPagas = 0;
    }
    
    /**
     * Exibe na tela os registros básicos da venda a vista
     */
    public void show(){
        if( comprador != null ){
            System.out.println("Cliente: "+comprador.getNome());
            System.out.println(" telefone: "+comprador.getTelefone());
        }
        else
            System.out.println("Cliente: (sem registro)");
        System.out.println("Vendedor: "+vendedor.getNome());
        System.out.printf("Valor: R$ %.2f\n", valor/100.0 );
        System.out.printf("Parcelas: %d / R$ %.2f\n", numeroParcelas, valorParcela/100.0 );
        System.out.println("Tipo Pagamento: "+tipoPagamento);
    }
    
    public void pagarParcela(){
        if( this.parcelasPagas < this.numeroParcelas )
            this.parcelasPagas += 1;
    }
}
