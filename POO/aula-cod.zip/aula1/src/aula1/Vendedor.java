package aula1;

/**
 * @author udesc
 */
public class Vendedor extends Pessoa{
    private int matricula;
    
    
    public Vendedor(int matricula, String nome, String tel){
        super( nome, tel );
        this.matricula = matricula;
    }

    /**
     * @return the matricula
     */
    public int getMatricula() {
        return matricula;
    }
    
}
