package poo;

import animais.Animal;
import animais.Cow;
import animais.Dog;
import animais.Gender;


public class POO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Dog c = new Dog("Totó", Gender.Male );
        System.out.println( c );
        
        Cow vaca = new Cow("Mimosa", 130);
        System.out.println( vaca );
        vaca.produceMilk( 52.30f );
    }
    
}
