package interfaces;

public class Rectangle implements Movable, Relatable {
    Point2D center;
    int width, height;
    
    public Rectangle(int w, int h){
        width = w;
        height = h;
        center = new Point2D();
    }
    
    @Override
    public double getArea(){
        return width * height;
    }

    @Override
    public void moveVertical(int units) {
        center.y += units;
    }

    @Override
    public void moveHorizontal(int units) {
        center.x += units;
    }
    
    @Override
    public boolean isLargerThan(Relatable other){
        if( !(other instanceof Rectangle) )
            return false;
        Rectangle aux = (Rectangle) other;
        if( this.getArea() > aux.getArea() )
            return true;
        return false;
    }
   
}
