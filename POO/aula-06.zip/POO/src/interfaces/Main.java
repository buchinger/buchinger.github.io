package interfaces;

public class Main {
   public static void main(String[] args){
       Rectangle rA = new Rectangle(5,3);
       Rectangle rB = new Rectangle(12,2);
       if( rA.isLargerThan( rB ) )
           System.out.println("rA é maior!");
       else
           System.out.println("rB é maior!");
       
       Relatable rC = new Rectangle(5,5);
       ((Rectangle) rC).getArea();
       
       Circle c = new Circle(1);
       if( c.isLargerThan( rA ) )
           System.out.println("c é maior!");
       else
           System.out.println("rA é maior!");
   } 
}
