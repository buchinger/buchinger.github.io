package interfaces;

public interface Movable {
    //public abstract void moveVertical(int units);
    void moveVertical(int units);
    void moveHorizontal(int units);
}
