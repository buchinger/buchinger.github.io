package interfaces;

public interface Relatable {
    boolean isLargerThan(Relatable other);
    double getArea();
}
