package interfaces;

public class Circle implements Movable, Relatable {

    Point2D center;
    double raio;
    
    public Circle(double raio){
        this.raio = raio;
        center = new Point2D();
    }
    
    public double getArea(){
        return Math.PI * raio * raio;
    }
    
    @Override
    public void moveVertical(int units) {
        center.y += units;
    }

    @Override
    public void moveHorizontal(int units) {
        center.x += units;
    }

    @Override
    public boolean isLargerThan(Relatable other) {
        if( this.getArea() > other.getArea() )
            return true;
        return false;
    }
    
     
}
