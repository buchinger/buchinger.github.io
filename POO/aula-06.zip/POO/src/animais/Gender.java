package animais;

public enum Gender {
    Male, Female;
}
