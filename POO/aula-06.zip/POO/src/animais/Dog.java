package animais;

public class Dog extends Animal {
    private Gender gender;
    
    public Dog(String nome, Gender gender){
        super( nome );
        this.gender = gender;
    }
    
    public Gender getGender(){
        return gender;
    }
    
    @Override
    public String toString(){
        return "Este cachorro se chama "+name;
    }
}
