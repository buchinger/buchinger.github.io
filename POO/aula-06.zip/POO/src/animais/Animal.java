package animais;

public abstract class Animal {
    public String name;
    private int age;
    
    public Animal(String name){
        this.name = name;
        age = 0;
    }
    
    public void anniversary(){
        age += 1;
        //age = age + 1;
    }
    
    public int getAge(){
        return age;
    }
    
    public abstract String toString();
    public String toString(boolean aux){
        return "yei! minha idade é "+age;
    }
}
