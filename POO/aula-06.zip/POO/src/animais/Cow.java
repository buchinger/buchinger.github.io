package animais;

public class Cow extends Animal {
    private static float totalMilkProduced = 0;
    private int weight;
    
    public Cow(String name, int w) {
        super(name);
        weight = w;
    }
    
    public void produceMilk(float producedMilk){
        Cow.totalMilkProduced += producedMilk;
    }

    @Override
    public String toString() {
        return "Isto é uma vaca e seu nome é: "+name +
                "\nEla possui "+weight+"kg";
    }
    
    
}
