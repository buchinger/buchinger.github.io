package aula.aula02;

/**
 * @author udesc
 */
public class Aula02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Personagem p1 = new Personagem("Bob", 2, 3, 4, 5);
        Personagem p2 = new Personagem("Jessica", 1, 3, 8, 4);
        //p1.setNome( "Outro nome" );
        p1.aumentaForca(-2);
        int hp = p1.getHP();
        //System.out.println("HP: "+hp);
        System.out.println("Personagens: "+Personagem.getCriados() );
        System.out.println( p1 );        
    }
    
}
