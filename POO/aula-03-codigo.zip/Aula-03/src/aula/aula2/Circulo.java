package aula.aula02;

/**
 * @author udesc
 */
public class Circulo {
    double raio;
    
    public Circulo(double r){
        raio = r;
    }
    public void showInfo(){
        System.out.println("--- CIRCULO ---");
        System.out.println("Raio: " + raio);
    }
}
