package aula.aula02;

/**
 * @author udesc
 */
public class Personagem {
    private String nome;
    private int constituicao;
    private int forca;
    private int destreza;
    private int agilidade;
    private static int criados = 0;
    
    
    public Personagem(String nome, int c, int f, int d, int a){
        setNome( nome );
        setConstituicao( c );
        setForca( f );
        setAgilidade( a );
        setDestreza( d );
        Personagem.criados += 1;
    }
    
    public static int getCriados(){
        return Personagem.criados;
    }
    
    public int getHP(){
        return getConstituicao()*100 + getForca()*5;
    }
    
    public int getConstituicao(){
        return constituicao;
    }
    public void setConstituicao( int c ){
        if( c < 0 )
            constituicao = 0;
        else 
            constituicao = c;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    private void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the forca
     */
    public int getForca() {
        return forca;
    }

    /**
     * @param forca the forca to set
     */
    private void setForca(int forca) {
        if( forca < 0 )
            this.forca = 0;
        else 
            this.forca = forca;
    }
    
    public boolean aumentaForca( int f ){
        if( f<0 )
            return false;
        int aux = getForca() + f;
        setForca( aux );
        return true;
    }

    /**
     * @return the destreza
     */
    public int getDestreza() {
        return destreza;
    }

    /**
     * @param destreza the destreza to set
     */
    public void setDestreza(int destreza) {
        this.destreza = destreza;
    }

    /**
     * @return the agilidade
     */
    public int getAgilidade() {
        return agilidade;
    }

    /**
     * @param agilidade the agilidade to set
     */
    public void setAgilidade(int agilidade) {
        this.agilidade = agilidade;
    }
    
    public String toString(){
        String t = "Nome: "+getNome()+"\n";
        t += "Constitução: "+getConstituicao()+"\n";
        t += "Força: "+getForca()+"\n";
        t += "Agilidade: "+getAgilidade()+"\n";
        return t;
    }
}
