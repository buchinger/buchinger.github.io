package aula.aula02;

/**
 * @author udesc
 */
public class Retangulo {
    double altura, largura;
    
    public Retangulo( double larg, double alt ){
        altura = alt;
        largura = larg;
    }
    
    public void showInfo(){
        System.out.println("--- RETANGULO ---");
        System.out.println("Largura: "+largura);
        System.out.println("Altura: "+altura);
    }
    
    public double area(){
        return largura * altura;
    }
    
    public double perimetro(){
        return 2*largura + 2*altura;
    }
}
