package aula.aula3;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.util.Locale;
import java.util.Scanner;

/**
 * @author udesc
 */
public class Main {
    
    public static void main(String[] args) throws Exception {
        File arquivo = new File("meu-arquivo.txt");
        FileInputStream input = new FileInputStream( arquivo );
        InputStreamReader reader = new InputStreamReader( input );
        Scanner scan = new Scanner( reader );
        //scan.useLocale( Locale.US );
        
        while( scan.hasNext() ){
            String linha = scan.nextLine();
            System.out.println( linha );
        }
        
        /*
        linha = scan.nextLine();
        System.out.println( linha );
        
        int va = scan.nextInt();
        int vb = scan.nextInt();
        System.out.println( "va: "+va );
        System.out.println( "vb: "+vb );
        */
        /*
        FileOutputStream output = new FileOutputStream(arquivo, true);
        String conteudo = "Ola meu arquivo\n";
        output.write( conteudo.getBytes() );
        output.close();*/
    }
    
    
    
    
    
    
    
    /*public static void main(String[] args) {
        double largura = 2.5;
        double altura = 6.0;
        Retangulo ret = new Retangulo( largura , altura );
        ret.showInfo(); //imprimir medidas do retangulo
        System.out.println("area = " + ret.area() + "perimetro = " + ret.perimetro());
        double raio = 3.75;
        Circulo cir = new Circulo( raio );
        cir.showInfo(); // imprimir valor do raio do círculo System.out.println("area = " + cir.area() + "perimetro = " + cir.perimetro()); }
    }*/
}
