package lista2;

/**
 * Esta classe abstrai a representação de um personagem
 * @author udesc
 */
public class Personagem {
    private String nome;
    private int forca, constituicao, destreza, agilidade;
    private static int contadorPersonagens = 0;
    
    
    public Personagem(String nome, int f, int c, int d, int a){
        this.nome = nome;
        setForca( f );
        setConstituicao( c );
        setDestreza( d );
        setAgilidade( a );
        contadorPersonagens += 1;
    }
    
    
    public int getHP(){
        return constituicao * 100 + forca * 5;
    }
    
    /**
     * Aumenta o atributo força do personagem em v unidades
     * @param v A quantidade, em unidades, em que o atributo será aumentado
     */
    public void aumentaForca(int v){
        if( v < 0 ) return;
        forca += v;
    }
    
    /**
     * Aumenta o atributo constituição do personagem em v unidades
     * @param v A quantidade, em unidades, em que o atributo será aumentado
     */
    public void aumentaConstituicao(int v){
        if( v < 0 ) return;
        constituicao += v;
    }
    
    /**
     * Aumenta o atributo destreza do personagem em v unidades
     * @param v A quantidade, em unidades, em que o atributo será aumentado
     */
    public void aumentaDestreza(int v){
        if( v < 0 ) return;
        destreza += v;
    }
    
    /**
     * Aumenta o atributo agilidade do personagem em v unidades
     * @param v A quantidade, em unidades, em que o atributo será aumentado
     */
    public void aumentaAgilidade(int v){
        if( v < 0 ) return;
        agilidade += v;
    }
    
    
    
    
    //-------------------------------------
    // MÉTODOS SETTER'S
    /**
     * Define um novo valor de força, de acordo
     * com as restrições do problema
     * @param novoValor O novo valor de força
     */
    public void setForca(int novoValor){
        if( novoValor<0 ) novoValor = 0;
        forca = novoValor;
    }
    /**
     * Define um novo valor de constituição,
     * de acordo com as restrições do problema
     * @param novoValor O novo valor de constituição
     */
    public void setConstituicao(int novoValor){
        if( novoValor<0 ) novoValor = 0;
        constituicao = novoValor;
    }
    /**
     * Define um novo valor de destreza,
     * de acordo com as restrições do problema
     * @param novoValor O novo valor de destreza
     */
    public void setDestreza(int novoValor){
        if( novoValor<0 ) novoValor = 0;
        destreza = novoValor;
    }
    /**
     * Define um novo valor de agilidade,
     * de acordo com as restrições do problema
     * @param novoValor O novo valor de agilidade
     */
    public void setAgilidade(int novoValor){
        if( novoValor<0 ) novoValor = 0;
        agilidade = novoValor;
    }
    
    
    //-------------------------------------
    // MÉTODOS GETTER'S
    /**
     * Retorna o número de personagens criados
     * durante a execução do programa.
     */
    public static int getContadorPersonagens(){
        return contadorPersonagens;
    }
    /**
     * Retorna o nome do personagem
     * @return retorna a string que representa
     * o nome do personagem.
     */
    public String getNome(){
        return nome;
    }
    /**
     * Retorna o valor do atributo força do personagem
     */
    public int getForca(){
        return forca;
    }
    /**
     * Retorna o valor do atributo constituição do personagem
     */
    public int getConstituicao(){
        return constituicao;
    }
    /**
     * Retorna o valor do atributo destreza do personagem
     */
    public int getDestreza(){
        return destreza;
    }
    /**
     * Retorna o valor do atributo agilidade do personagem
     */
    public int getAgilidade(){
        return agilidade;
    }
}
