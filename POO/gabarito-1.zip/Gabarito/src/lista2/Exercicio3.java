package lista2;

/**
 * Nesta classe temos o método main e fazemos uso
 * da classe Personagem, instanciando objetos dela.
 * @author udesc
 */
public class Exercicio3 {
    
    public static void main(String[] args){
        Personagem p1 = new Personagem("Goblin", 5, 3, -2, 17);
        Personagem p2 = new Personagem("Abyss Watcher", 57, 38, 28, 32);
        Personagem p3 = new Personagem("Chuck Noris", 99, 99, 99, 99);
        
        p1.aumentaDestreza( 3 );
        p2.aumentaConstituicao( 6 );
        
        int qtd = Personagem.getContadorPersonagens();
        System.out.println("Personagens criados: " + qtd);
        
        showPersonagem( p1 );
        showPersonagem( p2 );
        showPersonagem( p3 );
    }
    
    public static void showPersonagem( Personagem p ){
        System.out.println("---------------");
        System.out.println("Nome: "+p.getNome());
        System.out.println("         HP: " + p.getHP());
        System.out.printf("      Força: %2d  /  Constituicao: %2d\n", p.getForca(), p.getConstituicao());
        System.out.printf("  Agilidade: %2d  /      Destreza: %2d\n", p.getDestreza(), p.getAgilidade());
    }
    
}
