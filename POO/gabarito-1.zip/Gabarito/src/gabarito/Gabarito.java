package gabarito;

/**
 * Esta classe executa os códigos dos dois exercícios
 * implementados nos seus devidos pacotes.
 * @author udesc
 */
public class Gabarito {

    public static void main(String[] args) {
        System.out.println("***************************");
        System.out.println("LISTA 2 - EXERCÍCIO 3");
        lista2.Exercicio3.main( args );
        
        System.out.println("\n\n\n***************************");
        System.out.println("LISTA 3 - EXERCÍCIO 3");
        lista3.Exercicio3.main( args );
    }
    
}
