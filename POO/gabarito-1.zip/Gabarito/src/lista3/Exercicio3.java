package lista3;
import java.util.Random;

/**
 * Nesta classe temos o método main e fazemos uso
 * da classe Triangulo, instanciando objetos dela
 * de forma randomica e mostrando o resultado em tela.
 * @author udesc
 */
public class Exercicio3 {
    
    public static void main(String[] args){
        Random rnd = new Random();
        
        System.out.println("======================");
        System.out.println("Criação de Triângulos Retângulos:");
        for(int i=0; i<5; i++){
            double a = rnd.nextInt( 100 );
            double b = rnd.nextInt( 100 );
            Triangulo triangulo = new Triangulo(a, b);
            showTriangulo( triangulo );
        }
        
        System.out.println("======================");
        System.out.println("Criação de Triângulos:");
        for(int i=0; i<5; i++){
            double a = rnd.nextInt( 100 );
            double b = rnd.nextInt( 100 );
            double c = rnd.nextInt( 100 );
            Triangulo triangulo = new Triangulo(a, b, c);
            showTriangulo( triangulo );
        }
    }
    
    
    public static void showTriangulo( Triangulo t ){
        System.out.println("------- TRIÂNGULO INFO -------");
        System.out.printf("a = %3.1f  |  b = %3.1f  |  c = %3.1f\n", t.getLadoA(), t.getLadoB(), t.getLadoC() );
        boolean formaTriangulo = t.ehTriangulo();
        System.out.println("Triângulo válido: " + formaTriangulo );
        if( formaTriangulo ){
            System.out.printf("Área: %.2f\n", t.getArea() );
            System.out.print("Ângulos internos:");
            double[] angulos = t.getAngulos();
            for(int i=0; i<angulos.length; i++)
                System.out.printf("  %3.2f°", angulos[i] );
            System.out.println("");
        }
        System.out.println("");
    }
}
