package lista3;

/**
 * Esta classe abstrai a representação de um triângulo
 * @author udesc
 */
public class Triangulo {
    private double ladoA, ladoB, ladoC;
    
    /**
     * Construtor de triângulo que recebe três parâmetros
     * indicando os lados deste triângulo. Este construtor
     * não verifica se os valores utilizados são válidos,
     * ou seja, se geram realmente um triângulo.
     */
    public Triangulo( double a, double b, double c ){
        ladoA = a;
        ladoB = b;
        ladoC = c;
    }
    
    /**
     * Construtor de triângulos retângulos que recebe dois parâmetros
     * indicando os catetos deste triângulo. Este construtor
     * não verifica se os valores utilizados são válidos,
     * ou seja, se geram realmente um triângulo.
     * @param ca Valor real representando o cateto adjacente do triângulo
     * @param co Valor real representando o cateto oposto do triângulo
     */
    public Triangulo( double ca, double co ){
        ladoA = ca;
        ladoB = co;
        ladoC = Math.sqrt( ca*ca + co*co );
    }
    
    
    /**
     * Verifica se os valores definidos para os lados do triângulo
     * realmente formam um triângulo válido.
     * @return true se o triângulo é válido, caso contrário false.
     */
    public boolean ehTriangulo(){
        return ladoA > Math.abs( ladoB - ladoC ) &&
                ladoA < ladoB + ladoC &&
               ladoB > Math.abs( ladoA - ladoC ) &&
                ladoB < ladoA + ladoC &&
               ladoC > Math.abs( ladoA - ladoB ) &&
                ladoC < ladoA + ladoB;
    }
    
    
    /**
     * Calcula a área do triângulo usando a fórmula de Heron
     */
    public double getArea(){
        double p = (ladoA + ladoB+ ladoC) / 2;
        return Math.sqrt(p * (p-ladoA) * (p-ladoB) * (p-ladoC) );
    }
    
    
    /**
     * Calcula o ângulo entre dois vetores de valores 'a' e 'b'
     * utilizando a lei dos cossenos. O valor 'c' representa
     * o lado oposto ao ângulo que está sendo calculado
     * @return o ângulo entre 'a' e 'b' em graus
     */
    private static double calculaAngulo(double a, double b, double c){
        double ang = Math.acos( (-c*c + a*a + b*b) / (2*a*b) );
        return Math.toDegrees( ang );
    }
    
    
    /**
     * Calcula a área do triângulo usando a fórmula de Heron
     * @return Um vetor com três elementos representando os três
     *  ângulos internos do triângulo.
     */
    public double[] getAngulos(){
        double[] angulos = new double[3];
        angulos[0] = calculaAngulo(ladoA, ladoB, ladoC);
        angulos[1] = calculaAngulo(ladoA, ladoC, ladoB);
        angulos[2] = calculaAngulo(ladoC, ladoB, ladoA);
        return angulos;
    }

    /**
     * @return the ladoA
     */
    public double getLadoA() {
        return ladoA;
    }

    /**
     * @return the ladoB
     */
    public double getLadoB() {
        return ladoB;
    }

    /**
     * @return the ladoC
     */
    public double getLadoC() {
        return ladoC;
    }
    
    
    
    
}
