package dto;

/**
 * @author udesc
 */
public class Pessoa {
    private int rg;
    private String nome;
    private String telefone;
    
    public Pessoa( int rg, String nome, String telefone ){
        this.rg = rg;
        this.nome = nome;
        this.telefone = telefone;
    }
    
    
    public Pessoa clonar( ){
        Pessoa clone = new Pessoa( rg, nome, telefone);
        return clone;
    }

    
    /**
     * @return the rg
     */
    public int getRg() {
        return rg;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @return the telefone
     */
    public String getTelefone() {
        return telefone;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @param telefone the telefone to set
     */
    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
    
    
}
