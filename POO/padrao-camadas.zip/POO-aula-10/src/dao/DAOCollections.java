package dao;
import dto.Pessoa;
import java.util.ArrayList;

/**
 * @author udesc
 */
public class DAOCollections implements DAOInterface {
    
    private static DAOCollections instance = null;
    private ArrayList<Pessoa> contatos;

    private DAOCollections() {
        contatos = new ArrayList();
    }

    public static synchronized DAOCollections getInstance() {
        if (instance == null)
            instance = new DAOCollections();
        return instance;
    }

    @Override
    public boolean cadastrarContato(Pessoa p) {
        boolean res = contatos.add( p );
        return res;
    }

    @Override
    public boolean alterarContato(Pessoa p) {
       int rg = p.getRg();
       for( Pessoa aux : contatos ){
            if( aux.getRg() == rg ){
                aux.setNome( p.getNome() );
                aux.setTelefone( p.getTelefone() );
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean excluirContato(int rg) {
        for( Pessoa p : contatos ){
            if( p.getRg() == rg )
                return contatos.remove( p );
        }
        return false;
    }

    @Override
    public Pessoa consultarContato(int rg) {
        for( Pessoa p : contatos ){
            if( p.getRg() == rg )
                return p.clonar();
        }
        return null;
    }
    
    @Override
    public Pessoa[] resgatarContatos(){
        Pessoa[] c = new Pessoa[ contatos.size() ];
        contatos.toArray( c );
        return c;
    }
    
}
