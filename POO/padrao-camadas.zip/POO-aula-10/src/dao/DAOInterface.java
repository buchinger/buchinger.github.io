package dao;
import dto.Pessoa;

/**
 * @author udesc
 */
public interface DAOInterface {
    boolean cadastrarContato( Pessoa p );
    boolean alterarContato( Pessoa p );
    boolean excluirContato( int rg );
    Pessoa consultarContato( int rg );
    Pessoa[] resgatarContatos();
}
