package negocio;
import dao.DAOCollections;
import dao.DAOInterface;
import dto.Pessoa;

/**
 * Para este exemplo existem poucas regras de negócio.
 * Note que a única regra de negócio implementada foi a verificação de
 * unicidade de rg no método cadastrarContato. Contudo, poderia haver
 * mais regras a serem validadas.
 * @author udesc
 */
public class Negocio {
    
    static DAOInterface dao = DAOCollections.getInstance();
    
    /**
     * Verifica se não existe um contato com o mesmo cpf informado e
     * se não houver, cadastra o novo contato
     * @param p O registro do contato a ser cadastrado
     * @return Um valor booleano indicando se o registro do contato foi
     *  adicionado (true) ou não (false).
     */
    public static boolean cadastrarContato( Pessoa p ){
        // Validar se o cpf desta pessoa já não existe...
        Pessoa contatos[] = resgatarContatos();
        for( Pessoa aux : contatos ){
            if( aux.getRg() == p.getRg() )
                return false;
        }
        
        return dao.cadastrarContato( p );
    }
    
    
    /**
     * Resgata todos os contatos registrados no momento
     * @return um array de Pessoa com os contatos registrados
     */
    public static Pessoa[] resgatarContatos(){
        return dao.resgatarContatos();
    }
    
    
    
    /**
     * Consulta um dado registro de pessoa com base em um rg
     * @param rg
     * @return 
     */
    public static Pessoa consultarContato(int rg) {
        return dao.consultarContato(rg);
    }
    
    
    
    /**
     * Repassa a tentativa de alterar um contato
     * @param p
     * @return 
     */
    public static boolean alterarContato(Pessoa p){
        // Não faremos nenhuma validação neste caso, apenas passamos
        // a requisição adiante
        return dao.alterarContato( p );
    }
    
    
    
    /**
     * Repassa a tentativa de remover um contato
     * @param rg
     * @return 
     */
    public static boolean excluirContato(int rg){
        // Não faremos nenhuma validação neste caso, apenas passamos
        // a requisição adiante
        return dao.excluirContato( rg );
    }
    
}
