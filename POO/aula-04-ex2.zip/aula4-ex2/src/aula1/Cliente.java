package aula1;

/**
 * @author udesc
 */
public class Cliente {
    private String cpf;
    private String nome;
    private String endereco;
    private String telefone; 
    
    public Cliente(String cpf, String nome, String end, String tel){
        this.cpf = cpf;
        this.nome = nome;
        this.endereco = end;
        this.telefone = tel;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * Documentação sobre o método...
     * @return retorna o telefone formatado como: 9 9876-5432
     */
    public String getTelefone() {
        // 998765432
        // 012345678 indice
        // 9 9876-5432
        return telefone.charAt(0)+" "+
                telefone.substring(1,5)+"-"+
                telefone.substring(5);
    }

    /**
     * @return the cpf
     */
    public String getCpf() {
        return cpf;
    }

    /**
     * @return the endereco
     */
    public String getEndereco() {
        return endereco;
    }
}
