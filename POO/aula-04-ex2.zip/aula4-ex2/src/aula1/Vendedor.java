package aula1;

/**
 * @author udesc
 */
public class Vendedor {
    private int matricula;
    private String nome;
    private String telefone; 
    
    
    public Vendedor(int matricula, String nome, String tel){
        this.matricula = matricula;
        this.nome = nome;
        this.telefone = tel;
    }

    /**
     * @return the matricula
     */
    public int getMatricula() {
        return matricula;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * Documentação sobre o método...
     * @return retorna o telefone formatado como: 9 9876-5432
     */
    public String getTelefone() {
        // 998765432
        // 012345678 indice
        // 9 9876-5432
        return telefone.charAt(0)+" "+
                telefone.substring(1,5)+"-"+
                telefone.substring(5);
    }
    
}
