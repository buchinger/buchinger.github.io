package sistemaBancario;

/**
 * @author udesc
 */
public class Banco {
    String nome;
    int numIdentificador;
    Conta[] contas;
    private static final int MAX_CONTAS = 500;
    
    public Banco(String nome, int id){
        this.nome = nome;
        numIdentificador = id;
        contas = new Conta[MAX_CONTAS];
    }
    
    public boolean abrirConta(int agencia, int numero){
        for(int i=0; i<MAX_CONTAS; i++){
            if( contas[i] == null ){
                Conta novaConta = new Conta();
                novaConta.agencia = agencia;
                novaConta.numero = numero;
                novaConta.saldo = 0;
                contas[i] = novaConta;
                return true;
            }
        }
        return false;
    }
    
    public boolean fecharConta(int agencia, int numero){
        for(int i=0; i<MAX_CONTAS; i++){
            if( contas[i] == null )
                continue;
            if( contas[i].agencia == agencia &&
                contas[i].numero == numero ){
                    contas[i] = null;
                    return true;
            }
        }
        return false;
    }
    
}

class Conta{
    int agencia, numero;
    int saldo; // em centavos
    public boolean sacar( int valor ){
        if( saldo >= valor ){
            saldo -= valor;
            return true;
        }
        return false;
    }
    public void depositar(int valor){
        saldo += valor;
    }
}
