package aula04;
import sistemaBancario.Banco;


/**
 * @author udesc
 */
public class Main {
   
    public static void main(String[] args){
        //Carro carro = new Carro();
        //carro.marca.nome = "Ford";
        Banco bb = new Banco("BB", 1);
        bb.abrirConta(125, 29567);
        bb.abrirConta(127, 31254);
        bb.fecharConta(125, 29567);
    }
}
