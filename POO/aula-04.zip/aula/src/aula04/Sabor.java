package aula04;

/**
 * @author udesc
 */
public enum Sabor {
    DOCE(1,"Doce"), SALGADO(2, "Salgado");
    
    private int valor;
    private String nome;
    
    Sabor(int v, String n){
        valor = v;
        nome = n;
    }
 
    public String toString(){
        return "Sabor: " + nome;
    }
    
    public int getIDSabor(){
        return valor;
    }
}
