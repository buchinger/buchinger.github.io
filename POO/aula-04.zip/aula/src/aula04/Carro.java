package aula04;

// ASSOCIAÇÃO / AGREGAÇÃO / COMPOSIÇÃO

/**
 * @author udesc
 */
public class Carro {
    String modelo;
    Marca marca;
    Pneu[] pneu;
}

class Marca{
    String nome;
}

class Pneu{
    int pressao;
    void encherPneu(){
        pressao += 5;
    }
}