package aula04;

/**
 *
 * @author udesc
 */
public class Prato {
    String nome;
    int serve;
    Sabor sabor;
    
    public Prato(String n, int s){
        nome = n;
        serve = s;
        sabor = Sabor.SALGADO;
    }
    public Prato(String n, int s, Sabor sabor){
        nome = n;
        serve = s;
        this.sabor = sabor;
    }
    
    public boolean ehSalgado(){
        if( sabor == Sabor.SALGADO )
            return true;
        return false;
    }
    
    
    public static void main(String[] args){
        System.out.println( Sabor.SALGADO );
        System.out.println( Sabor.DOCE.getIDSabor() );
    }
}
