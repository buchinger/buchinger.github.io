package aula;

/**
 * @author udesc
 */
public class Time {
    private String nome;
    private int vitorias, empates, derrotas;
    private int pontosFeitos, pontosSofridos;
    
    public Time(String nome){
        this.nome = nome;
        vitorias = empates = derrotas = 0;
        pontosFeitos = pontosSofridos = 0;
    }
    
    /**
     * Recebe os dados de uma partida e
     * atualiza os dados do time 
     * @param pf - pontos feitos
     * @param ps - pontos sofridos
     */
    public void computaPartida( int pf, int ps ){
        if( pf > ps )
            vitorias += 1;
        else if( pf == ps )
            empates += 1;
        else // pf < ps
            derrotas += 1;
        pontosFeitos += pf;
        pontosSofridos += ps;
    }
    
    /**
     * Calcula e retorna a pontuação atual do time
     */
    public int getPontuacao(){
        return vitorias*2 - derrotas;
    }
    
    // GETTERS
    public int getPontosFeitos(){
        return pontosFeitos;
    }
    public int getPontosSofridos(){
        return pontosSofridos;
    }
}
