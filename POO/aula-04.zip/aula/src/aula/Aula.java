package aula;
import java.util.Scanner;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;

/**
 * @author udesc
 */
public class Aula {

    static Scanner teclado = new Scanner(System.in);
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        int opcao;
        
        do{
            System.out.println("Menu");
            System.out.println("1 - Adicionar novo registro");
            System.out.println("2 - Consultar dados Klingon");
            System.out.println("0 - Sair");
            opcao = Aula.teclado.nextInt();
            if( opcao==1 ){
                adicionarRegistro();
            }
            else if( opcao==2 ){
                consultarPontuacao("Klingon");
            }
        } while( opcao!=0 );
    }
    
    
    public static void adicionarRegistro() throws Exception {
        File arquivo = new File("aula-03.txt");
        FileOutputStream output = new FileOutputStream(arquivo, true);
        // Lê o pulo de linha após o inteiro do menu
        Aula.teclado.nextLine();
        
        System.out.print("Digite o nome do time da casa: ");
        String timeCasa = Aula.teclado.nextLine();
        System.out.print("Digite o nome do time visitante: ");
        String timeVisitante = Aula.teclado.nextLine();
        System.out.print("Qual a pontuação do time da casa: ");
        int timeCasaPontos = Aula.teclado.nextInt();
        System.out.print("Qual a pontuação do time visitante: ");
        int timeVisitantePontos = Aula.teclado.nextInt();
        String registro = timeCasa + ";" + timeCasaPontos;
        registro = registro + ";" + timeVisitantePontos + ";";
        registro = registro + timeVisitante + "\r\n";
        output.write(  registro.getBytes()  );
        output.close();
    }
    
    
    
    public static void consultarPontuacao(String nomeTime) throws Exception  {
        File arquivo = new File("aula-03.txt");
        FileInputStream input = new FileInputStream( arquivo );
        InputStreamReader reader = new InputStreamReader( input );
        Scanner leitor = new Scanner( reader );
        
        Time equipe = new Time( nomeTime );
        while( leitor.hasNext() ){
            String linha = leitor.nextLine();
            if( linha.contains(nomeTime ) ){
                String[] dados = linha.split(";");
                if( dados[0].equals(nomeTime ) ){
                    int pf = Integer.parseInt( dados[1] );
                    int ps = Integer.parseInt( dados[2] );
                    equipe.computaPartida( pf , ps );
                }
                else{
                    int pf = Integer.parseInt( dados[2] );
                    int ps = Integer.parseInt( dados[1] );
                    equipe.computaPartida( pf , ps );
                }
            }
            // else: ignore a linha
        }
        System.out.println("Situação no campeonato:");
        System.out.println("Pontuação: " + equipe.getPontuacao());
        System.out.println("Pontos Feitos: " + equipe.getPontosFeitos());
        System.out.println("Pontos Sofridos: " + equipe.getPontosSofridos());
        System.out.println("Pressione Enter para continuar...");
        teclado.nextLine(); // lê o pulo de linha após a opção de menu
        teclado.nextLine(); // lê o pulo de linha requisitado..
    }
    
    
}
