package sistemaAcademico;

/**
 * @author udesc
 */
public class Turma {
    private String disciplina;
    private int semestre;
    private Aluno[] alunos;
    private static final int MAX_ALUNOS_POR_TURMA = 40;
    
    public Turma(String disciplina, int semestre){
        this.disciplina = disciplina;
        this.semestre = semestre;
        alunos = new Aluno[MAX_ALUNOS_POR_TURMA];
    }
    
    public boolean matricular( Aluno aluno ){
        // verificar se há vaga
        boolean vaga = false;
        int i;
        for(i=0; i<alunos.length; i++){
            if( alunos[i] == null ){
                alunos[i] = aluno;
                vaga = true;
                break;
            }
        }
        if( vaga==false ) return false;
        
        boolean res = aluno.matricular( this );
        if( res==false ){
            alunos[i] = null;
            return false;
        }
        return true;
    }
    
    public void listarAlunos( ){
        System.out.println("ALUNOS DE "+disciplina+": ");
        for(int i=0; i<alunos.length; i++){
            if( alunos[i] != null )
                System.out.println( alunos[i].getNome() );
        }
    }
}
