package sistemaAcademico;

/**
 * @author udesc
 */
public class Universidade {
    
    private static final int MAX_ALUNOS = 500;
    private static final int MAX_TURMAS = 100;
    static Aluno[] alunos;
    static Turma[] turmas;
    
    public static void main(String[] args){
        Universidade udesc = new Universidade();
        turmas[5].matricular( alunos[0] );
    }
    
    public Universidade(){
        alunos = new Aluno[MAX_ALUNOS];
        turmas = new Turma[MAX_TURMAS];
    }
}
