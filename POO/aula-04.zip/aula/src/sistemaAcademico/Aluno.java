package sistemaAcademico;

/**
 * @author udesc
 */
public class Aluno {
    private String nome;
    private int matricula;
    private String endereco;
    private Turma[] matriculado;
    private static final int MAX_AULAS = 8;
    
    public Aluno(String nome, int matricula, String endereco){
        this.nome = nome;
        this.matricula = matricula;
        this.endereco = endereco;
        matriculado = new Turma[MAX_AULAS];
    }
    
    public boolean matricular(Turma turma){
        for(int i=0; i<matriculado.length; i++){
            // aluno tem disponibilidade para se matricular na turma
            if( matriculado[i] == null ){
                matriculado[i] = turma;
                return true;
            }
        }
        return false;
    }

    
    public void listarTurmas( ){
        System.out.println("TURMAS DE "+nome+": ");
        /*for( todas as turmas da univerdade )
            for( para cada aluno da turma){
            if( alunos[i].matricula == matricula )
                System.out.println( nome da turma ) );
        }*/
    }
    
    
    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the matricula
     */
    public int getMatricula() {
        return matricula;
    }

    /**
     * @param matricula the matricula to set
     */
    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    /**
     * @return the endereco
     */
    public String getEndereco() {
        return endereco;
    }

    /**
     * @param endereco the endereco to set
     */
    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }
}
