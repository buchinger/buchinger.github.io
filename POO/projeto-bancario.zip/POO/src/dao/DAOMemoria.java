package dao;
import eda.Administrador;
import eda.Cliente;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * @author udesc
 */
public class DAOMemoria implements DAOInterface {
    static DAOMemoria instancia = null;
    
    Administrador adm = new Administrador(101, "abcd");
    ArrayList<Cliente> clientes = new ArrayList<Cliente>();
    int limitePorOperacao = 600;
    
    private DAOMemoria(){
        init();
    }
    private void init(){
        Cliente c = new Cliente("Tester", 12345);
        clientes.add( c );
    }
    
    public static DAOMemoria getInstance(){
        if( instancia==null )
            instancia = new DAOMemoria();
        return instancia;
    }

    @Override
    public void inserirCliente(Cliente c) {
        clientes.add( c );
    }

    @Override
    public Cliente getCliente(int conta) {
        for( Cliente cli : clientes ){
            if( cli.getConta() == conta )
                return cli;
        }
        return null;
    }

    @Override
    public boolean validarCredenciais(int matricula, String senha) {
        if( matricula==adm.getMatricula() &&
            senha.equals(adm.getSenha()) )
            return true;
        return false;
    }
    
    @Override
    public boolean depositar(int conta, int valor){
        Iterator<Cliente> it = clientes.iterator();
        while( it.hasNext() ){
            Cliente aux = it.next();
            if( aux.getConta() == conta ){
                int saldo = aux.getSaldo();
                saldo += valor;
                aux.setSaldo( saldo );
                return true;
            }
        }
        return false;
    }
    
    @Override
    public boolean debitar(int conta, int valor){
        return depositar( conta, -valor );
    }
    
    @Override
    public int getLimitePorOperacao(){
        return limitePorOperacao;
    }
}
