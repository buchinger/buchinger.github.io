package dao;

import eda.*;

/**
 * @author udesc
 */
public interface DAOInterface {
    public void inserirCliente( Cliente c );
    public Cliente getCliente( int conta );
    public boolean validarCredenciais( int matricula, String senha);
    public boolean depositar(int conta, int valor);
    public boolean debitar(int conta, int valor);
    public int getLimitePorOperacao();
    
}
