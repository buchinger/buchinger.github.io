package eda;

/**
 * @author udesc
 */
public class Administrador {
    private int matricula;
    private String senha;
    
    public Administrador(int mat, String s){
        this.matricula = mat;
        this.senha = s;
    }

    /**
     * @return the matricula
     */
    public int getMatricula() {
        return matricula;
    }

    /**
     * @return the senha
     */
    public String getSenha() {
        return senha;
    }

    /**
     * @param senha the senha to set
     */
    public void setSenha(String senha) {
        this.senha = senha;
    }
}
