package eda;

/**
 * @author udesc
 */
public class Status {
    public boolean erro;
    public String mensagem;
    
    public Status(){
        erro = false;
        mensagem = "";
    }
    
    public void addErro(String msg){
        mensagem += msg;
        erro = true;
    }
}
