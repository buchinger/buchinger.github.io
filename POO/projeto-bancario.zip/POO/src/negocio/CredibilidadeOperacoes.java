package negocio;

import eda.Cliente;

/**
 * @author udesc
 */
public class CredibilidadeOperacoes {
    static boolean possuiSaldo( int conta, int valor ){
        Cliente cliente = NegocioFacade.DAO.getCliente( conta );
        if( cliente == null )
            return false;
        if( cliente.getSaldo() < valor )
            return false;
        return true;
    }
}
