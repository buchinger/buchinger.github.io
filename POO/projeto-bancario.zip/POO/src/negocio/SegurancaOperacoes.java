package negocio;

/**
 * @author udesc
 */
public class SegurancaOperacoes {
    static boolean atendeLimite( int valor ){
        int limite = NegocioFacade.DAO.getLimitePorOperacao();
        return valor <= limite;
    }
}
