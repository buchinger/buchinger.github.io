package negocio;

import dao.DAOInterface;
import dao.DAOMemoria;
import eda.*;

/**
 * @author udesc
 */
public class NegocioFacade {
    static DAOInterface DAO = DAOMemoria.getInstance();
    
    private NegocioFacade(){ }
    
    // TODO::: criar um método para realizar transferência!
    
    /**
     * 
     * @param numeroConta
     * @return 
     */
    public static Cliente validarConta( int numeroConta ){
        Cliente cli = DAO.getCliente( numeroConta );
        return cli;
    }
    
    
    /**
     * 
     * @param conta
     * @param valor
     * @return 
     */
    public static Status depositar( int conta, int valor ){
        boolean retorno = DAO.depositar(conta, valor);
        Status status = new Status();
        if( retorno == false )
            status.addErro("A conta não existe");
        return status;
    }
    
    
    
    public static Status sacar( int conta, int valor ){
        Status status = new Status();        
        
        // Validações de segurança
        boolean res = SegurancaOperacoes.atendeLimite( valor );
        if( res==false ){
            status.addErro("Valor excede o limite por operação!");
            return status;
        }
        // Validações de disponibilidade
        res = CredibilidadeOperacoes.possuiSaldo(conta, valor);
        if( res==false ){
            status.addErro("Cliente não possui saldo!");
            return status;
        }
        
        boolean retorno = DAO.debitar(conta, valor);
        if( retorno == false )
            status.addErro("A conta não existe");
        return status;
    }
}
