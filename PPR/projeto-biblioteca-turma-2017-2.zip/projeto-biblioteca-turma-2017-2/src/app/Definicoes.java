package app;
import EDA.Administrador;

/**
 * @author UDESC
 */
public class Definicoes {
    public static Administrador adm;  
    private Definicoes(){  }
}
