package app;
import EDA.*;
import java.util.ArrayList;
import java.util.Scanner;
import negocio.NegocioFacade;


public class AppConsole {
    private AppConsole(){ }
    static Scanner teclado = new Scanner( System.in );
    
    
    public static void main(String[] args) {
        boolean continuar = true;
        do{
            System.out.println("Bem vindo ao sistema bibliotecario de Exceter City!");
            do{
                Definicoes.adm = AppConsole.login();
                if( Definicoes.adm == null )
                    System.out.println("Credenciais Inválidas!!");
            } while( Definicoes.adm == null );

            AppConsole.mostrarMenuPrincipal( Definicoes.adm );
            
        } while( continuar );
    }
    
    
    
    /**
     * Faz diálogo com o usuário para realizar o login
     * @return retorna os dados do administrador ou nulo caso as credenciais não sejam válidas
     */
    static Administrador login(){
        System.out.print("Login: ");
        String login = teclado.nextLine();
        System.out.print("Senha: ");
        String senha = teclado.nextLine();
        
        Administrador adm = NegocioFacade.login( login, senha );
        return adm;
    }
    
    
    static void mostrarMenuPrincipal(Administrador adm){
        for( ; ; ){
            System.out.println("\n\nBem vindo bibliotecario "+adm.getNome());
            System.out.println("Menu de Opções:");
            System.out.println("(1) Cadastrar Usuário");
            System.out.println("(2) Cadastrar Livro");
            System.out.println("(3) Cadastrar Exemplar");
            System.out.println("(4) Realizar Empréstimo");
            System.out.println("(5) Realizar Devolução");
            System.out.println("(6) Realizar Reserva");
            System.out.println("(7) Listar Usuários");
            System.out.println("(8) Listar Empréstimos");
            System.out.println("(9) Listar Livros");
            System.out.println("(10) Listar Livros por Titulo");
            System.out.println("(11) Listar Livros por Gênero");
            System.out.println("(12) Log out");
            System.out.print("Digite o número da opção: ");
            
            int opcao = teclado.nextInt();
            switch( opcao ){
                case 1: cadastrarUsuario(); break;
                case 2: cadastrarLivro(); break;
                case 3: cadastrarExemplar(); break;
                case 4: emprestar(); break;
                case 5: devolver(); break;
                case 6: reservar(); break;
                case 7: listarUsuarios(); break;
                case 8: listarEmprestimos(); break;
                case 9: listarLivros(); break;
                case 10: listarLivrosTitulo(); break;
                case 11: listarLivrosGenero(); break;
                case 12: return;
                default:
                    System.out.println("Tu tá maluco? Essa opção não existe!");
                    Toolbox.pressEnter(teclado);
            }
        }
    }
    
    
    static boolean perguntaSimNao(){
        for(;;){
            System.out.print("Responda (S-Sim / N-não): ");
            String resposta = teclado.nextLine();
            if( resposta.equals("S") || resposta.equals("s") )
                return true;
            if( resposta.equals("N") || resposta.equals("n") )
                return false;
            System.out.println("Você é um jumento?! Você tem que responder sim ou não!");
        }
    }
    
    
    static void cadastrarUsuario(){
        boolean repete;
        do{
            System.out.println("\n\nCADASTRAR USUÁRIO\n");
            System.out.print("Digite o RG do novo usuário: ");
            int rg = teclado.nextInt();
            System.out.print("Digite o número da carteirinha do novo usuário: ");
            int carteirinha = teclado.nextInt();
            Toolbox.clearBuffer( teclado );
            System.out.print("Digite o nome do novo usuário: ");
            String nome = teclado.nextLine();
            System.out.print("Digite o endereço do novo usuário: ");
            String endereco = teclado.nextLine();
            System.out.print("Digite o telefone do novo usuário: ");
            String telefone = teclado.nextLine();
            Usuario usuario = new Usuario(nome, endereco, telefone, rg, carteirinha);
            Operacao retorno = NegocioFacade.cadastrarUsuario( usuario );
            if( retorno.getStatus() == true ){
                System.out.println("Novo usuário inserido com sucesso no sistema!");
                System.out.println("Deseja inserir um novo usuário?");
                repete = perguntaSimNao();
            }
            else{
                System.out.println("Erro ao inserir novo usuário!");
                System.out.println( retorno.getErro() );
                System.out.println("----------------");
                System.out.println("Deseja tentar novamente?");
                repete = perguntaSimNao();
            }
        } while( repete );
    }
    
    
    
    // Lucas Cobucci
    static void cadastrarLivro(){
        boolean repete = true;
        
        System.out.printf("Cadastrar um novo livro\n");
        while( repete ){
            System.out.print("Digite o codigo do livro: ");
            int codigoLivro = teclado.nextInt();

            Toolbox.clearBuffer( teclado );
            System.out.print("Digite o nome da editora: ");
            String nomeEditora = teclado.nextLine();

            System.out.print("Digite o titulo do livro: ");
            String tituloLivro = teclado.nextLine();

            System.out.print("Digite o(s) autor(es) do livro: ");
            String autoresLivro = teclado.nextLine();

            System.out.print("Digite o genero: ");
            String generoLivro = teclado.nextLine();

            System.out.print("Digite o ano do livro: ");
            int anoLivro = teclado.nextInt();

            Toolbox.clearBuffer( teclado );
            System.out.print("Digite o local onde ficará armazenado: ");
            String localLivro = teclado.nextLine();
            
            Livro livro = new Livro(codigoLivro, nomeEditora, tituloLivro, autoresLivro, generoLivro, anoLivro, localLivro);

            Operacao retorno = NegocioFacade.cadastrarLivro( livro );
            if( retorno.getStatus() == true ){
                System.out.println("Cadastro do livro realizado");
                System.out.println("Deseja cadastrar um novo livro?");
                repete = perguntaSimNao();
            }
            else{
                System.err.println("Erro ao inserir novo livro!");
                System.err.println( retorno.getErro() );
                System.err.println("----------------");
                System.err.println("Deseja tentar novamente?");
                repete = perguntaSimNao();
            }
        }
    }
    
    static void cadastrarExemplar(){
        // @TODO
    }
    
    
    // Victor
    static void emprestar(){
        boolean repete;
        do{
            System.out.print("Digite o número da carteirinha: ");
            int carteirinha = teclado.nextInt();
            System.out.print("Digite o código do livro: ");
            int cod_livro = teclado.nextInt();
            System.out.print("Digite o número de dias de empréstimo: ");
            int dias = teclado.nextInt();
            Operacao retorno = NegocioFacade.emprestarExemplar( carteirinha, cod_livro, dias );
            if( retorno.getStatus() == true ){
                System.out.println("Operação concluída com sucesso no sistema!");
                System.out.println("Deseja realizar novo empréstimo?");
                repete = perguntaSimNao();
            }
            else{
                System.err.println("Erro ao realizar operação");
                System.err.println( retorno.getErro() );
                System.err.println("----------------");
                System.err.println("Deseja tentar novamente?");
                repete = perguntaSimNao();
            }
        } while( repete );
    }
    
    static void devolver(){
        // @TODO
    }
    
    // Renato
    static void reservar(){
        boolean repete;
        do{
            System.out.println("\n\nRESERVAR LIVRO\n");
            System.out.print("Digite o número da carteirinha do usuário a reservar o livro: ");
            int carteirinha = teclado.nextInt();
            Toolbox.clearBuffer( teclado );
            System.out.print("Digite o código do livro: ");
            int cod_livro = teclado.nextInt();
            System.out.print("Digite o número de sequência do exemplar: ");
            int seq = teclado.nextInt();
            Operacao retorno = NegocioFacade.reservarExemplar( carteirinha, cod_livro, seq);
            if( retorno.getStatus() == true ){
                System.out.println("Livro reservado com sucesso!");
                System.out.println("Deseja reservar um outro livro?");
                repete = perguntaSimNao();
            }
            else{
                System.out.println("Erro ao reservar livro!");
                System.out.println( retorno.getErro() );
                System.out.println("----------------");
                System.out.println("Deseja tentar novamente?");
                repete = perguntaSimNao();
            }
        } while( repete );
    }
    
    static void listarUsuarios(){
        System.out.println("\n\nUSUÁRIO CADASTRADOS\n");
        ArrayList<Usuario> usuarios = NegocioFacade.getUsuarios();
        if( usuarios.size()==0 )
            System.out.println("Nenhum usuário cadastrado no sistema =(");
        
        for( Usuario usr : usuarios ){
            System.out.printf("Carteirinha: %-13s   |   RG: %d\n", usr.getCarteirinha(), usr.getRg());
            System.out.printf("Nome: %-20s   |   Telefone: %s\n", usr.getNome(), usr.getTelefone());
            System.out.println("Endereço: "+usr.getCarteirinha());
            System.out.println("Multa: R$ "+usr.getMulta());           
        }
        Toolbox.pressEnter(teclado);
    }
    
    // Matheus Alano
    static void listarEmprestimos(){
        /*System.out.println("\n\nREALIZAR EMPR�STIMO\n");
        System.out.print("Digite o numero da carteirinha: ");
        int carteirinha = teclado.nextInt();
        System.out.print("Digite o numero do exemplar: ");
        int exemplar = teclado.nextInt();
        System.out.print("Informe a quantidade de dias: ");
        int dias = teclado.nextInt();
        Emprestimo emprestimo = new Emprestimo( , ,dias);
        
        
        // Kleiton Pereira
        System.out.println("\n\nEMPRESTIMOS\n");
        ArrayList<Usuario> usuarios = NegocioFacade.getUsuarios();
        if( usuarios.size()==0 )
            System.out.println("Nenhum usu�rio cadastrado no sistema =(");

        for(Usuario u: usuarios){
            ArrayList<Emprestimo> emprestimos = NegocioFacade.getEmprestimos(u);
            System.out.printf("Carteirinha: %-13s   |   RG: %d\n", u.getCarteirinha(), u.getRg());
            System.out.printf("Nome: %-20s   |   Telefone: %s\n", u.getNome(), u.getTelefone());
            System.out.printf("############ EMPR�STIMOS ############\n");
            for(Emprestimo e: emprestimos){
                System.out.printf("Exemplar: %-16s\n", e.getExemplar());
                System.out.printf("Data de Empr�stimo: %-6s\n", e.getData_emprestimo());
                System.out.printf("Data de Devolu��o: %-7s\n", e.getData_devolucao());
                System.out.printf("N�mero de Renova��es: %-3s\n", e.getRenovacoes());
            }
            System.out.printf("#####################################\n\n");
        }
        Toolbox.pressEnter(teclado);
        */
    }
    
    
    static void listarLivros(){
        System.out.println("Lista de Livros Cadastrados");
        ArrayList<Livro> livros;
        livros = NegocioFacade.getLivros( null, null );
        for(Livro aux : livros){
            System.out.printf("Cod: %d\n", aux.getCodigo());
            System.out.printf("Título: %-20s   |   Gênero: %s\n", aux.getTitulo(), aux.getGenero());
            System.out.printf("Autores: %s\n", aux.getAutor());
            System.out.printf("Editora: %-20s  |   Ano Publicação: %d\n", aux.getNome(), aux.getAno_publicacao());
            System.out.printf("Localização: %s\n", aux.getLocalizacao());
            System.out.printf("------------------------------\n");
        }
        Toolbox.pressEnter( teclado );
    }
    
    
    static void listarLivrosTitulo(){
        System.out.println("Lista de Livros Cadastrados por Titulo");
        System.out.println("Qual titulo deseja filtrar: ");
        Toolbox.clearBuffer( teclado );
        String titulo_escolhido = teclado.nextLine();
        
        ArrayList<Livro> livros;
        livros = NegocioFacade.getLivros( null, titulo_escolhido );
        for(Livro aux : livros){
            System.out.printf("Cod: %d\n", aux.getCodigo());
            System.out.printf("Título: %-20s   |   Gênero: %s\n", aux.getTitulo(), aux.getGenero());
            System.out.printf("Autores: %s\n", aux.getAutor());
            System.out.printf("Editora: %-20s  |   Ano Publicação: %d\n", aux.getNome(), aux.getAno_publicacao());
            System.out.printf("Localização: %s\n", aux.getLocalizacao());
            System.out.printf("------------------------------\n");
        }
        Toolbox.pressEnter( teclado );
    }
    
    
    
    // Leonardo Miotto
    static void listarLivrosGenero(){
        System.out.println("Lista de Livros Cadastrados por Genero");
        System.out.println("Qual genero deseja filtrar: ");
        Toolbox.clearBuffer( teclado );
        String genero_escolhido = teclado.nextLine();
        
        ArrayList<Livro> livros;
        livros = NegocioFacade.getLivros( null, genero_escolhido );
        for(Livro aux : livros){
            System.out.printf("Cod: %d\n", aux.getCodigo());
            System.out.printf("Título: %-20s   |   Gênero: %s\n", aux.getTitulo(), aux.getGenero());
            System.out.printf("Autores: %s\n", aux.getAutor());
            System.out.printf("Editora: %-20s  |   Ano Publicação: %d\n", aux.getNome(), aux.getAno_publicacao());
            System.out.printf("Localização: %s\n", aux.getLocalizacao());
            System.out.printf("------------------------------\n");
        }
        Toolbox.pressEnter( teclado );
    }
}
