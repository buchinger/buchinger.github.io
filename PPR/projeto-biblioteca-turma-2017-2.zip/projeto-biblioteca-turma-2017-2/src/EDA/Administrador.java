
package EDA;


public class Administrador extends Pessoa {
    private String login;
    private String senha;

    public Administrador(String n, String e, String t, int rg, String login, String senha) {
        super(n, e, t, rg);
        this.login = login;
        this.senha = senha;
    }

    /**
     * @return the login
     */
    public String getLogin() {
        return login;
    }

    /**
     * @return the senha
     */
    public String getSenha() {
        return senha;
    }
}
