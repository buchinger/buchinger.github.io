package negocio;
import EDA.*;
import java.util.ArrayList;

/**
 * @author UDESC
 */
public class Controlador {
    private Controlador(){}
    
    
    /**
     * Calcula o valor da multa em relação a quantidade de dias de atraso
     * na devolução de um exemplar
     * @param dias_atraso a quantidade de dias em atraso
     * @return o valor da multa que deverá ser paga pelo usuário
     */
    public static float calculaMulta( int dias_atraso ){
        //@TODO
        float multa = 0;
        return multa;
    }
    
    
    /**
     * Verifica se um dado exemplar está disponível para empréstimo
     * (ou seja, não está emprestado, nem reservado e não é o primeiro exemplar)
     * e se o usuário está em situação de ficha limpa para emprestar (multa zero)
     * @param ex exemplar que se deseja verificar disponibilidade
     * @param usu usuário que se deseja verificar situação
     * @return <b>true</b> se o exemplar e o usuário estiverem aptos a
     *   a participarem de um empréstimo, ou <b>false</b> caso contrário.
     */
    public boolean verificaDispExemplar( Exemplar ex, Usuario usu ){
        //@TODO
        return true;
    }
    
    
    
    public ArrayList<Livro> getLivrosTitulo( String titulo ){
        //@TODO
        return null;
    }
    
    
    public ArrayList<Livro> getLivrosGenero( String genero ){
        //@TODO
        return null;
    }
    
    
    static boolean estaReservado( Exemplar exemplar ){
        //@TODO
        return false;
    }
    
}
