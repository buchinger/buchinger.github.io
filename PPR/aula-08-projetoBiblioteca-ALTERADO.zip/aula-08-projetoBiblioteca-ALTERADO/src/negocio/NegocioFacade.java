package negocio;
import DAO.DAOFacade;
import DAO.DAOMemoria;
import EDA.*;
import java.util.ArrayList;

public class NegocioFacade {
    static final DAOFacade registros = DAOMemoria.get();
    
    private NegocioFacade(){ }
    
    /**
     * Tenta realizar o login de um bibliotecário através das informações de
     *      login e senha que são recebidas como parâmetro
     * @param login um texto contendo o nome de usuário (login)
     * @param senha um texto contendo a senha do usuário
     * @return um objeto Administrador referente ao bibliotecário, ou null
     *      caso as credenciais estejam erradas.
     */
    public static Administrador login(String login, String senha){
        senha = Toolbox.encrypt( senha );
        Administrador adm = registros.verificarCredenciais( login, senha );
        return adm;
    }
    
    /**
     * Verifica a validade de alguns dados do usuário e insere-o no sistema
     * @param usuario o novo usuário a ser inserido no sistema
     * @return <b>true</b> se o novo usuário for inserido com sucesso ou <b>false</b> caso contrário
     */
    public static Operacao cadastrarUsuario( Usuario usuario ){
        // verifica os dados do usuário
        Operacao status = new Operacao( );
        if( usuario.getNome().length() <= 3 )
            status.anexarErro("O nome é muito curto");
        if( usuario.getEndereco().length() <= 3 )
            status.anexarErro("O endereço é muito curto");
        if( usuario.getTelefone().length() <= 8 )
            status.anexarErro("O telefone é muito curto");
        if( status.getStatus() ){
            boolean res = registros.cadastrarUsuario( usuario );
            if( res == false )
                status.anexarErro("Erro ao registrar dados do usuário!");
        }
        return status;
    }
    
    
    public static Operacao cadastrarLivro( Livro livro ){ return null; }

    
    /**
     *   Recebe um exemplar, verifica se ele tem um código único e se o livro está cadastrado no sistema, depois retorna se deu tudo certo ou não
     *   [Felipe Weiss e Arthur Felipe Herdt Schuelter]
    */
    public static Operacao cadastrarExemplar( Exemplar exemplar ){ 
        Operacao status = new Operacao();       
        
        ArrayList<Exemplar> exemplares = new ArrayList();
        exemplares = registros.getExemplares();
        boolean exemplarOk = true;
        for(Exemplar e : exemplares){
            if(e.getNseq() == exemplar.getNseq()){
                exemplarOk = false;
                status.anexarErro("Código do exemplar inválido!");
                break;
            }
        }
        if(exemplarOk){
            ArrayList<Livro> livros = new ArrayList();
            livros = registros.getLivros();
            boolean livroCadastrado = false;
            for(Livro l : livros){
                if(l == exemplar.getLivro()){
                    livroCadastrado = true;
                    break;
                }
            }
            if(livroCadastrado){
                registros.cadastrarExemplar(exemplar);
            } else {
                status.anexarErro("Livro não cadastrado!");
            }
        }
        return status;
    }
        
        
    public static Operacao emprestarExemplar( int carteirinha, int cod_livro, int seq ){ return null; }
    public static float devolverExemplar( int cod_livro, int seq ){ return 0; }
    public static Operacao renovarExemplar( int cod_livro, int seq ){ return null; }
    public static Operacao reservarExemplar( int carteirinha, int cod_livro, int seq ){ return null; }
    public static ArrayList<Emprestimo> getUsuario( int carteirinha ){ return null; }
    
    
    
    /**
     * Retorna todos os usuários cadastrados no sistema
     * @return um array list com todos os usuários cadastrados
     */
    public static ArrayList<Usuario> getUsuarios( ){
        return registros.getUsuarios();
    }
    
    
    
    /**
     * Retorna todos os livros cadastrados no sistema em acordo 
     * os filtros passados por parâmetro
     * @param titulo filtra os livros que possuem o título informado.
     *      Caso a string esteja vazia, o filtro por título não é aplicado.
     * @param genero filtra os livros que possuem o gênero informado
     *      Caso a string esteja vazia, o filtro por gênero não é aplicado.
     * @return um array list com todos os livros cadastrados que
     *      atendem aos filtros especificados.
     */
    public static ArrayList<Livro> getLivros( String titulo, String genero ){
        //@TODO
        return null;
    }
    
    
    
    
    /**
     * Retorna os registros de todos os exemplares (disponíveis ou indisponíveis)
     * de um dado livro.
     * @param cod_livro o código do livro do qual se deseja resgatar os exemplares.
     * @return Uma lista com todos os exemplares do livro de código cod_livro.
     */
    public static ArrayList<Exemplar> getExemplares( int cod_livro ){
        ArrayList<Exemplar> res = new ArrayList();
        for( Exemplar exe : registros.getExemplares() ){
            if( exe.getLivro().getCodigo() == cod_livro )
                res.add( exe );
        }
        return res;
    }
    
    
    /**
     * Resgata todos os empréstimos pendentes de um dado usuário
     * @param usuario o usuário que se deseja consultar as pendências
     * @return uma lista com todos os empréstimos pendentes do usuário
     *      passado por parâmetro.
     */
    public static ArrayList<Emprestimo> getEmprestimos( Usuario usuario ){
        ArrayList<Emprestimo> lista_emprestimos = new ArrayList();
        for(Emprestimo emp : registros.getEmprestimos()){
            if( emp.getUsuario() == usuario )
                lista_emprestimos.add( emp );
        }
        return lista_emprestimos;
    }
    
}
