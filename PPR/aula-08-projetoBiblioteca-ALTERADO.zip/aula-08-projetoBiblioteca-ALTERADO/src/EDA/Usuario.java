package EDA;

public class Usuario extends Pessoa{
    private int carteirinha;
    private float multa;
    
    public Usuario(String n, String e, String t, int rg, int id) {
        super(n, e, t, rg);
        carteirinha = id;
        multa = 0;
    }
    
    public void novaMulta( float valor ){
        multa += valor;
    }

    /**
     * @return the carteirinha
     */
    public int getCarteirinha() {
        return carteirinha;
    }

    /**
     * @return the multa
     */
    public float getMulta() {
        return multa;
    }
    
    
    
}
