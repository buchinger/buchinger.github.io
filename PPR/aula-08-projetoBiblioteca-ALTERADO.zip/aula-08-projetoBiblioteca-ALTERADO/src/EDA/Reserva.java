package EDA;

import java.time.LocalDate;

/**
 * @author UDESC
 */
public class Reserva {
    private final Usuario usuario;
    private final Exemplar exemplar;
    private final LocalDate data_reserva;
    
    public Reserva(Usuario usu, Exemplar exe){
        usuario = usu;
        exemplar = exe;
        data_reserva = LocalDate.now();
    }

    
    
    /**
     * @return o usuario
     */
    public Usuario getUsuario() {
        return usuario;
    }

    /**
     * @return o exemplar
     */
    public Exemplar getExemplar() {
        return exemplar;
    }

    /**
     * @return a data_reserva
     */
    public LocalDate getData_reserva() {
        return data_reserva;
    }
    
    
}
