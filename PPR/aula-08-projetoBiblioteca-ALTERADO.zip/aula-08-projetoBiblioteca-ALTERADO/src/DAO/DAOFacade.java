package DAO;
import EDA.*;
import java.util.ArrayList;

public interface DAOFacade {
    public Administrador verificarCredenciais(String login, String senha);
    public boolean cadastrarUsuario(Usuario usuario);
    public boolean cadastrarLivro(Livro livro);
    public boolean cadastrarExemplar(Exemplar exemplar);
    public boolean cadastrarReserva(Reserva reserva);
    public boolean criarEmprestimo(Emprestimo emp);
    /**
     * Remove um empréstimo cadastrado no sistema - devolução de livro
     */
    public boolean removerEmprestimo(Emprestimo emp);
    /**
     * Altera o tempo de empréstimo de um livro.
     */
    public boolean alterarEmprestimo(Emprestimo emp, int dias);
    /**
     * Retorna todos os usuários cadastrados
     */
    public ArrayList<Usuario> getUsuarios();
    /**
     * Retorna todos os livros cadastrados
     */
    public ArrayList<Livro> getLivros();
    /**
     * Retorna todos exemplares cadastrados
     */
    public ArrayList<Exemplar> getExemplares();
    /**
     * Retorna todos os empréstimos de livros cadastrados
     */
    public ArrayList<Emprestimo> getEmprestimos();
    /**
     * Retorna todas as reservas de livros cadastradas
     */
    public ArrayList<Reserva> getReservas();
}
