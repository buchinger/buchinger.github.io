package DAO;

import EDA.*;
import java.util.ArrayList;

public class DAOMemoria implements DAOFacade{
    private static DAOMemoria memoria;
    
    private Administrador bibliotecario;
    private ArrayList<Usuario> usuarios = new ArrayList();
    private ArrayList<Livro> livros = new ArrayList();
    private ArrayList<Exemplar> exemplares = new ArrayList();
    private ArrayList<Emprestimo> emprestimos = new ArrayList();
    private ArrayList<Reserva> reservas = new ArrayList();
    
    
    public static DAOMemoria get(){
        if( memoria == null )
            memoria = new DAOMemoria();
        return memoria;
    }
    
    private DAOMemoria(){
        init();
    }
    private void init(){
        bibliotecario = new Administrador("Joao da Silva", "UDESC", "999999", 123777, "udesc", "785b10a64d56af61e802913738e7d567");
        Usuario user1 = new Usuario("Alice Berk", "Rua Dali de Perto, Jville", "99988-3210", 6534222, 1);
        usuarios.add( user1 );
        usuarios.add( new Usuario("Bob Claviculus", "Rua Lá de Longe, Guaratuaba", "98899-0123", 2453215, 2) ); 
        usuarios.add( new Usuario("Clotiude Dante", "Rua dos Leitores, Campo Alegre", "98998-4567", 4321651, 3) ); 
        livros.add( new Livro(1, "teste", "teste", "teste", "teste", 2010, "teste") );
        livros.add( new Livro(2, "livro", "oieee", "ola", "cambio", 2011, "olaaa") );
        livros.add( new Livro(11, "tchau", "quase acambando", "ola", "nao sei", 2015, "olaaa") );
    }
    
    
    
    @Override
    public Administrador verificarCredenciais(String login, String senha) {
        if( bibliotecario.getLogin().compareTo(login)==0  &&  bibliotecario.getSenha().compareTo(senha)==0 )
            return bibliotecario;
        return null;
    }

    @Override
    public boolean cadastrarUsuario(Usuario usuario) {
        // Verifica se não existe um usuário já cadastrado com esta carteririnha
        for( Usuario usr : usuarios ){
            if( usr.getCarteirinha() == usuario.getCarteirinha() )
                return false;
        }
        return usuarios.add( usuario );
    }

    @Override
    public boolean cadastrarLivro(Livro livro) {
        // Verifica se não existe um livro já cadastrado com o codigo
        for( Livro aux : livros ){
            if( aux.getCodigo() == livro.getCodigo() )
                return false;
        }
        return livros.add( livro );
    }
    
    
    @Override
    public boolean alterarLivro(Livro livro){
        // Verifica se o livre existe        
        for( Livro aux : livros ){
            if( aux.getCodigo() == livro.getCodigo() ){
                livros.remove( aux );
                livros.add( livro );
                return true;
            }
        }
        return false;
    }
    

    @Override
    public boolean cadastrarExemplar(Exemplar exemplar) {
        // Verifica se não existe outro exemplar do mesmo livro com mesmo código de sequencia
        for( Exemplar exe : exemplares ){
            if( exe.getLivro() == exemplar.getLivro() && exe.getNseq() == exemplar.getNseq() )
                return false;
        }
        return exemplares.add( exemplar );
    }

    
    @Override
    public boolean cadastrarReserva(Reserva reserva) {
        return reservas.add( reserva );
    }
    
    
    @Override
    public boolean criarEmprestimo(Emprestimo emp) {
        return emprestimos.add( emp );
    }

    @Override
    public boolean removerEmprestimo(Emprestimo emp) {
        return emprestimos.remove( emp );
    }

    @Override
    public boolean alterarEmprestimo(Emprestimo emp, int dias) {
        emp.renovar( dias );
        return false;
    }
    
    @Override
    public ArrayList<Usuario> getUsuarios() {
        return usuarios;
    }
    
    @Override
    public ArrayList<Livro> getLivros() {
        return livros;
    }
    
    @Override
    public ArrayList<Exemplar> getExemplares(){
        return exemplares;
    }
    
    @Override
    public ArrayList<Emprestimo> getEmprestimos() {
        return emprestimos;
    }

    @Override
    public ArrayList<Reserva> getReservas() {
        return reservas;
    }
    
}
