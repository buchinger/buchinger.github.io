package app;

import EDA.Administrador;

/**
 * @author UDESC
 */
public class Main {
    public static Administrador adm;
    public static TelaMenu tela_menu;
    
    private Main(){}
    
    public static void main(String args[]){
        TelaLogin tela = new TelaLogin();
        tela.setVisible( true );
    }
}
