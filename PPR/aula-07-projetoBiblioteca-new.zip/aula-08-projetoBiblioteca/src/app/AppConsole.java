package app;
import EDA.*;
import java.util.ArrayList;
import java.util.Scanner;
import negocio.NegocioFacade;


public class AppConsole {
    private AppConsole(){ }
    static Scanner teclado = new Scanner( System.in );
    
    
    public static void main(String[] args) {
        boolean continuar = true;
        do{
            System.out.println("Bem vindo ao sistema bibliotecario de Exceter City!");
            do{
                Definicoes.adm = AppConsole.login();
                if( Definicoes.adm == null )
                    System.out.println("Credenciais Inválidas!!");
            } while( Definicoes.adm == null );

            AppConsole.mostrarMenuPrincipal( Definicoes.adm );
            
        } while( continuar );
    }
    
    
    
    /**
     * Faz diálogo com o usuário para realizar o login
     * @return retorna os dados do administrador ou nulo caso as credenciais não sejam válidas
     */
    static Administrador login(){
        System.out.print("Login: ");
        String login = teclado.nextLine();
        System.out.print("Senha: ");
        String senha = teclado.nextLine();
        
        Administrador adm = NegocioFacade.login( login, senha );
        return adm;
    }
    
    
    static void mostrarMenuPrincipal(Administrador adm){
        for( ; ; ){
            System.out.println("\n\nBem vindo bibliotecario "+adm.getNome());
            System.out.println("Menu de Opções:");
            System.out.println("(1) Cadastrar Usuário");
            System.out.println("(2) Cadastrar Livro");
            System.out.println("(3) Cadastrar Exemplar");
            System.out.println("(4) Realizar Empréstimo");
            System.out.println("(5) Realizar Devolução");
            System.out.println("(6) Realizar Reserva");
            System.out.println("(7) Listar Usuários");
            System.out.println("(8) Listar Empréstimos");
            System.out.println("(9) Listar Livros");
            System.out.println("(10) Listar Livros por Titulo");
            System.out.println("(11) Listar Livros por Gênero");
            System.out.println("(12) Log out");
            System.out.print("Digite o número da opção: ");
            
            int opcao = teclado.nextInt();
            Toolbox.clearBuffer( teclado );
            switch( opcao ){
                case 1: cadastrarUsuario(); break;
                case 2: cadastrarLivro(); break;
                case 3: cadastrarExemplar(); break;
                case 4: emprestar(); break;
                case 5: devolver(); break;
                case 6: reservar(); break;
                case 7: listarUsuarios(); break;
                case 8: listarEmprestimos(); break;
                case 9: listarLivros(); break;
                case 10: listarLivrosTitulo(); break;
                case 11: listarLivrosGenero(); break;
                case 12: return;
                default:
                    System.out.println("Tu tá maluco? Essa opção não existe!");
                    Toolbox.pressEnter(teclado);
            }
        }
    }
    
    
    static boolean perguntaSimNao(){
        for(;;){
            System.out.print("Responda (S-Sim / N-não): ");
            String resposta = teclado.nextLine();
            if( resposta.equals("S") || resposta.equals("s") )
                return true;
            if( resposta.equals("N") || resposta.equals("n") )
                return false;
            System.out.println("Você é um jumento?! Você tem que responder sim ou não!");
        }
    }
    
    
    static void cadastrarUsuario(){
        boolean repete;
        do{
            System.out.println("\n\nCADASTRAR USUÁRIO\n");
            System.out.print("Digite o RG do novo usuário: ");
            int rg = teclado.nextInt();
            System.out.print("Digite o número da carteirinha do novo usuário: ");
            int carteirinha = teclado.nextInt();
            Toolbox.clearBuffer( teclado );
            System.out.print("Digite o nome do novo usuário: ");
            String nome = teclado.nextLine();
            System.out.print("Digite o endereço do novo usuário: ");
            String endereco = teclado.nextLine();
            System.out.print("Digite o telefone do novo usuário: ");
            String telefone = teclado.nextLine();
            Usuario usuario = new Usuario(nome, endereco, telefone, rg, carteirinha);
            Operacao retorno = NegocioFacade.cadastrarUsuario( usuario );
            if( retorno.getStatus() == true ){
                System.out.println("Novo usuário inserido com sucesso no sistema!");
                System.out.println("Deseja inserir um novo usuário?");
                repete = perguntaSimNao();
            }
            else{
                System.out.println("Erro ao inserir novo usuário!");
                System.out.println( retorno.getErro() );
                System.out.println("----------------");
                System.out.println("Deseja tentar novamente?");
                repete = perguntaSimNao();
            }
        } while( repete );
    }
    
    
    /**
     * A partir dos valores recebidos, solicita o cadastro de um novo livro no sistema
     */
    static void cadastrarLivro(){
        boolean repete;
        do {
            System.out.println("\n\nCADASTRAR LIVRO\n");
            System.out.print("Digite o código do livro: ");
            int cod = teclado.nextInt();
            Toolbox.clearBuffer( teclado );
            System.out.print("Digite a editora do livro: ");
            String editora = teclado.nextLine();
            System.out.print("Digite o título do livro: ");
            String titulo = teclado.nextLine();
            System.out.print("Digite o autor do livro: ");
            String autor = teclado.nextLine();
            System.out.print("Digite o gênero do livro: ");
            String genero = teclado.nextLine();
            System.out.print("Digite o ano de publicação do livro: ");
            int ano = teclado.nextInt();
            Toolbox.clearBuffer( teclado );
            System.out.print("Digite a localização do livro: ");
            String localizacao = teclado.nextLine();
            Livro livro = new Livro(cod, editora, titulo, autor, genero, ano, localizacao);
            Operacao op = NegocioFacade.cadastrarLivro( livro );
            if(op.getStatus() == true) {
                System.out.println("Novo livro inserido com sucesso no sistema.");
                System.out.println("Deseja inserir um novo livro?");
                repete = perguntaSimNao();
            } else {
                System.out.println("Erro ao inserir novo livro!");
                System.out.println(op.getErro());
                System.out.println("----------------");
                System.out.println("Deseja tentar novamente?");
                repete = perguntaSimNao();
            }
        }while( repete );
    }
    
    // Recebendo informações para o cadastro de um novo exemplar.
    static void cadastrarExemplar(){      
        boolean repete;
         boolean repeticao = true;
         Livro book = null;
        do{
            System.out.println("\n\nCADASTRAR EXEMPLAR\n");
            do{
            System.out.println("Digite o código do livro");
            int code = teclado.nextInt();
            ArrayList <Livro>lista = NegocioFacade.getLivros("", "");
            
            for(Livro livro: lista){
                if(livro.getCodigo()==code){
                    book = livro;
                    repeticao = false;
                    
                }
            }
            }while(repeticao);
            System.out.println("Digite o número do exemplar");
            int nseq = teclado.nextInt();
            System.out.println("Digite as observações sobre o exemplar");
            String observacao = teclado.nextLine();
            Toolbox.clearBuffer( teclado );
            
            Exemplar exemplar = new Exemplar(book, nseq, observacao);
            Operacao retorno = NegocioFacade.cadastrarExemplar( exemplar );
            if( retorno.getStatus() == true ){
                System.out.println("Novo exemplar inserido com sucesso no sistema!");
                System.out.println("Deseja inserir um novo exemplar?");
                repete = perguntaSimNao();
            }
            else{
                System.out.println("Erro ao inserir novo exemplar!");
                System.out.println( retorno.getErro() );
                System.out.println("----------------");
                System.out.println("Deseja tentar novamente?");
                repete = perguntaSimNao();
            }
        } while( repete );
    }
    
    
    
    //Andre Eduardo e Wilton Jaciel Loch
    static void emprestar() { 
        boolean repete;
        do {
            System.out.println("\n\nREALIZAR EMPRÉSTIMO\n"); 
           System.out.print("Digite o número da carteirinha do usuário: ");
            int carteirinha = teclado.nextInt();
            System.out.print("Digite o código do livro: ");
            int cod_livro = teclado.nextInt();            
            System.out.print("Digite o número de sequencia do exemplar: ");
            int nseq = teclado.nextInt();           
            Operacao retorno = NegocioFacade.emprestarExemplar(carteirinha, cod_livro, nseq);
            if (retorno.getStatus() == true) {
                System.out.println("Empréstimo realizado com sucesso!");
                System.out.println("Deseja realizar um novo empréstimo?");
                repete = perguntaSimNao();
            } else {
                System.out.println("Erro ao emprestar exemplar!");
                System.out.println(retorno.getErro());
                System.out.println("----------------");
                System.out.println("Deseja tentar novamente?");
                repete = perguntaSimNao();
            }
        } while (repete);
    }
    
    
    
    static void devolver(){
        // @TODO
    }
    
    
    
    /**
     * Solicita a reserva de um exemplar através dos dados inseridos pelo usuário
     */
    static void reservar(){
        boolean repete;
        do{
            System.out.println("\n\nRESERVAR LIVRO\n");
            System.out.println("Digite o número da carteirinha: ");
            int carteirinha = teclado.nextInt();
            System.out.println("Digite o código do livro: ");
            int cod_livro = teclado.nextInt();
            System.out.println("Digite o código de sequencia do exemplar: ");
            int seq = teclado.nextInt();
            Operacao retorno = NegocioFacade.reservarExemplar(carteirinha, cod_livro, seq);            
            if( retorno.getStatus() == true ){
                System.out.println("Reserva realizada com sucesso!");
                System.out.println("Deseja realizar uma nova reserva?");
                repete = perguntaSimNao();
            }
            else{
                System.out.println("Erro ao reservar!");
                System.out.println( retorno.getErro() );
                System.out.println("----------------");
                System.out.println("Deseja tentar novamente?");
                repete = perguntaSimNao();
            }
        } while( repete );
    }
    
    static void listarUsuarios(){
        System.out.println("\n\nUSUÁRIO CADASTRADOS\n");
        ArrayList<Usuario> usuarios = NegocioFacade.getUsuarios();
        if( usuarios.size()==0 )
            System.out.println("Nenhum usuário cadastrado no sistema =(");
        
        for( Usuario usr : usuarios ){
            System.out.printf("Carteirinha: %-13s   |   RG: %d\n", usr.getCarteirinha(), usr.getRg());
            System.out.printf("Nome: %-20s   |   Telefone: %s\n", usr.getNome(), usr.getTelefone());
            System.out.println("Endereço: "+usr.getCarteirinha());
            System.out.println("Multa: R$ "+usr.getMulta());
            System.out.println("--------------------");
        }
        Toolbox.pressEnter(teclado);
    }
    
    static void listarEmprestimos(){
        System.out.println("\n\nEMPRÉSTIMOS CADASTRADOS\n");
        boolean resposta = true;
        Usuario usuario = null;
        do{
            System.out.print("Digite a carteirinha do usuário a consultar: ");
            int carteirinha = teclado.nextInt();
            teclado.nextLine();
            usuario = NegocioFacade.getUsuario( carteirinha );
            if( usuario != null ) break;
            System.out.print("Carteirinha inexistente. Deseja tentar novamente?");
            resposta = perguntaSimNao();
            if( !resposta ) return;
        } while( resposta );
        
        ArrayList<Emprestimo> emprestimos = NegocioFacade.getEmprestimos( usuario );
        if( emprestimos.size()==0 )
            System.out.println("Nenhum empréstimo cadastrado no sistema...");
        
        for( Emprestimo emp : emprestimos ){
            System.out.printf("Titulo livro: %-13s\n", emp.getExemplar().getLivro().getTitulo());
            System.out.printf("Data Emprestimo: %02d / %02d   |   Data Devolução: %02d / %02d\n", 
                        emp.getData_emprestimo().getDayOfMonth(), emp.getData_emprestimo().getMonthValue(),
                        emp.getData_devolucao().getDayOfMonth(), emp.getData_devolucao().getMonthValue() );
            System.out.println("--------------------");
        }
        Toolbox.pressEnter(teclado);
    }
    
    
    /**
     * adaptado
     * [desenvolvido por Bruno Luis Vieira]
     */
    static void listarLivros(){
        System.out.println("\n\nLIVROS CADASTRADOS\n");
        ArrayList<Livro> livros = NegocioFacade.getLivros("", "");
        if( livros.size()==0 ){
            System.out.println("Nenhum livro cadastrado no sistema =(");
        }
        for( Livro aux : livros ){
            System.out.printf("Título: %s    |   Ano: %d\n", aux.getTitulo(), aux.getAno_publicacao());
            System.out.printf("Autores: %s    |   Gênero: %s\n", aux.getAutor(), aux.getGenero());
        }
        Toolbox.pressEnter(teclado);
    }
    
    /**
     * adaptado
     * [desenvolvido por Bruno Luis Vieira]
     */
    static void listarLivrosTitulo(){
        System.out.printf("Título: ");
        String titulo = teclado.nextLine();
        ArrayList<Livro> livros = NegocioFacade.getLivros(titulo, "");
        if( livros.size()==0 ){
            System.out.println("Nenhum Livro com este Título cadastrado no sistema =(");
        }
        for( Livro aux : livros ){
            System.out.printf("Título: %s    |   Ano: %d\n", aux.getTitulo(), aux.getAno_publicacao());
            System.out.printf("Autores: %s    |   Gênero: %s\n", aux.getAutor(), aux.getGenero());
        }
        Toolbox.pressEnter(teclado);
    }
    
    /**
     * adaptado
     * [desenvolvido por Bruno Luis Vieira]
     */
    static void listarLivrosGenero(){
        System.out.printf("Gênero: ");
        String genero = teclado.nextLine();
        ArrayList<Livro> livros = NegocioFacade.getLivros("", genero);
        if( livros.size()==0 ){
            System.out.println("Nenhum Livro com este gênero cadastrado no sistema =(");
        }
        for( Livro aux : livros ){
            System.out.printf("Título: %s    |   Ano: %d\n", aux.getTitulo(), aux.getAno_publicacao());
            System.out.printf("Autores: %s    |   Gênero: %s\n", aux.getAutor(), aux.getGenero());
        }
        Toolbox.pressEnter( teclado );
    }
}
