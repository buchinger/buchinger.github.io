package negocio;
import EDA.*;
import java.util.ArrayList;

/**
 * @author UDESC
 */
public class Controlador {
    private Controlador(){}
    
    
    /**
     * Calcula o valor da multa em relação a quantidade de dias de atraso
     * na devolução de um exemplar
     * [*Felipe de Avila]
     * @param dias_atraso a quantidade de dias em atraso
     * @return o valor da multa que deverá ser paga pelo usuário
     */
    public static float calculaMulta( int dias_atraso ){
        float multa = 0;
        if(dias_atraso <= 3){
            multa = (float) (dias_atraso*(0.25));
        }
        if(dias_atraso > 3 && dias_atraso <= 7){    
            multa = ((float) ((dias_atraso-3)*(0.75))) + calculaMulta(3);
        }
        if(dias_atraso > 7){
            multa = ((float) ((dias_atraso-7)*(1.00))) + calculaMulta(3)+ calculaMulta(7) ;
        }
        return multa;
    }
    
   
    
    /**
     * Verifica se um dado exemplar está disponível para empréstimo
     * (ou seja, não está emprestado, nem reservado e não é o primeiro exemplar)
     * e se o usuário está em situação de ficha limpa para emprestar (multa zero)
     *  [Desenvolvedores: Leonardo Valério Anastácio, Lucas Litter Mentz.]
     * @param ex exemplar que se deseja verificar disponibilidade
     * @param usu usuário que se deseja verificar situação
     * @return <b>true</b> se o exemplar e o usuário estiverem aptos a
     *   a participarem de um empréstimo, ou <b>false</b> caso contrário.
     */
    public static boolean verificaDispExemplar( Exemplar exe, Usuario usu ){
        boolean ret = true;
        if( usu.getMulta() > 0 || 
            exe.getNseq() == 1 ||
            estaReservado( exe ) == true ) //Nigga stole my bike
        {
            ret = false;
        }
        
        ArrayList<Emprestimo> tmp = NegocioFacade.registros.getEmprestimos();
        for ( Emprestimo emp : tmp )
            if ( emp.getExemplar() == exe )
                ret = false;
        
        return ret;
    }
    
    
    
    public static ArrayList<Livro> getLivrosTitulo( String titulo ){
        ArrayList<Livro> livros = new ArrayList();
        for( Livro livro : NegocioFacade.registros.getLivros() ){
            if( livro.getTitulo().equalsIgnoreCase(titulo) )
                livros.add( livro );
        }
        return livros;
    }
    
    
    public static ArrayList<Livro> getLivrosGenero( String genero ){
        ArrayList<Livro> livros = new ArrayList();
        for( Livro livro : NegocioFacade.registros.getLivros() ){
            if( livro.getGenero().equalsIgnoreCase(genero ) )
                livros.add( livro );
        }
        return livros;
    }
    
    
    public static boolean estaReservado( Exemplar exemplar ){
        for( Reserva reserva : NegocioFacade.registros.getReservas() ){
            if( reserva.getExemplar() == exemplar )
                return true;
        }
        return false;
    }
    
}
