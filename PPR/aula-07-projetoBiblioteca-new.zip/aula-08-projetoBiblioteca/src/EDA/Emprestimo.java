package EDA;
import java.time.LocalDate;

/**
 * @author UDESC
 */
public class Emprestimo {
    private final Usuario usuario;
    private final Exemplar exemplar;
    private final LocalDate data_emprestimo;
    private LocalDate data_devolucao;
    private int renovacoes;
    
    public Emprestimo(Usuario usu, Exemplar exe, int dias){
        usuario = usu;
        exemplar = exe;
        data_emprestimo = LocalDate.now();
        data_devolucao = data_emprestimo.plusDays( dias );
        renovacoes = 0;
    }
    
    /**
     * Renovar um empréstimo. A data de devolução será: data atual + dias (parâmetro)
     * @param dias a quantidade de dias, a partir da data atual, que o usuário
     *      terá para devolver o exemplar
     */
    public void renovar( int dias ){
        data_devolucao = LocalDate.now().plusDays( dias );
        renovacoes += 1;
    }

    /**
     * @return o usuario
     */
    public Usuario getUsuario() {
        return usuario;
    }

    /**
     * @return o exemplar
     */
    public Exemplar getExemplar() {
        return exemplar;
    }

    /**
     * @return a data_emprestimo
     */
    public LocalDate getData_emprestimo() {
        return data_emprestimo;
    }

    /**
     * @return a data_devolucao
     */
    public LocalDate getData_devolucao() {
        return data_devolucao;
    }

    /**
     * @return o número de renovacoes
     */
    public int getRenovacoes() {
        return renovacoes;
    }
    
    
           
}
