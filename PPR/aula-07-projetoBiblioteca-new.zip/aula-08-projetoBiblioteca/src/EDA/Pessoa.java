package EDA;

public class Pessoa {

    private final String nome;
    private final String endereco;
    private final String telefone;
    private final int rg;
    
    public Pessoa( String n, String e, String t, int rg ){
        nome = n;
        endereco = e;
        telefone = t;
        this.rg = rg;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @return the endereco
     */
    public String getEndereco() {
        return endereco;
    }

    /**
     * @return the telefone
     */
    public String getTelefone() {
        return telefone;
    }

    /**
     * @return the rg
     */
    public int getRg() {
        return rg;
    }
    
    
}
