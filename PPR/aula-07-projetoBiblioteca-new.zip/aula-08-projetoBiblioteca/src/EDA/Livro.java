package EDA;

import java.util.ArrayList;

public class Livro {
    private final int codigo;
    private final String nome;
    private final String titulo;
    private final String autor;
    private final String genero;
    private final int ano_publicacao;
    private final String localizacao;
    
    public Livro( int cod, String nom, String tit, String aut, String gen, int ano, String loc ){
        codigo = cod;
        nome = nom;
        titulo = tit;
        autor = aut;
        genero = gen;
        ano_publicacao = ano;
        localizacao = loc;
    }
    
    
    /**
     * @return the codigo
     */
    public int getCodigo() {
        return codigo;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @return the titulo
     */
    public String getTitulo() {
        return titulo;
    }

    /**
     * @return the autor
     */
    public String getAutor() {
        return autor;
    }

    /**
     * @return the genero
     */
    public String getGenero() {
        return genero;
    }

    /**
     * @return the ano_publicacao
     */
    public int getAno_publicacao() {
        return ano_publicacao;
    }

    /**
     * @return the localizacao
     */
    public String getLocalizacao() {
        return localizacao;
    }

}
