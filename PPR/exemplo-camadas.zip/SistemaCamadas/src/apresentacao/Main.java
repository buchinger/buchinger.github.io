/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package apresentacao;

import Negocio.Academia;
import Negocio.NegocioFacade;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class Main {
    public final static String ADM_LOGIN = "admin";
    public final static String ADM_PASSWORD = "FCE5DE4D28CD57202C019279BCA4B8B336E8A3F7EC30DE04E56CF84993F2CEC5";
    static NegocioFacade negocio = new Academia();
    
    public static void main(String args[]){
        new TelaLogin().setVisible(true);
    }
    
}
