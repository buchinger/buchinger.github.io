
package Negocio;

import DAO.DAOFacade;
import DAO.Memoria;
import ED.Pessoa;
import java.util.List;

/**
 *
 * @author UDESC
 */
public class Academia implements NegocioFacade {
    private final DAOFacade dao = new Memoria();
    
    
    @Override
    public boolean inserirPessoa(Pessoa p) {
        // Precisamos verificar, por causa de uma regra de negócio,
        // que a idade não pode ser superior a 99 anos ou inferior a 10 anos
        if( p.getIdade() > 99 && p.getIdade() > 10 )
            return false;
        return dao.inserirPessoa( p );
    }

    @Override
    public Pessoa consultarPessoa(long cpf) {
        return dao.consultarPessoa( cpf );
    
    }
    @Override
    public List<Pessoa> getPessoas(){
        return dao.getPessoas();
    }

    @Override
    public boolean removerPessoa(long cpf) {
        return dao.removerPessoa(cpf);
    }
    
    
}
