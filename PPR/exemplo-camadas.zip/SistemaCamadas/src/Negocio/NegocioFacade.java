
package Negocio;
import ED.Pessoa;
import java.util.List;

public interface NegocioFacade {
    
    public boolean inserirPessoa( Pessoa p );
    public Pessoa consultarPessoa( long cpf );
    public List<Pessoa> getPessoas();
    public boolean removerPessoa(long cpf);
}
