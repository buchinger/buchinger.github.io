package ED;

public class Util {
    
    
    
    final protected static char[] hexArray = "0123456789ABCDEF".toCharArray();
    /**
     * Converte um vetor de bytes em uma string de valores hexadecimais
     * @param bytes O vetor de bytes a ser convertido para hexadecimal
     * @return Uma string contendo valores hexadecimais que representam o vetor de bytes
     */
    public static String bytesToHex(byte[] bytes) {
        char[] hexChars = new char[bytes.length * 2];
        for ( int j = 0; j < bytes.length; j++ ) {
            int v = bytes[j] & 0xFF;
            hexChars[j * 2] = hexArray[v >>> 4];
            hexChars[j * 2 + 1] = hexArray[v & 0x0F];
        }
        return new String(hexChars);
    }
    
    
    
}
