package interfaces;

/**
 * @author UDESC
 */
public class Main {

    static Messenger mensageiro = new PrintMessager();
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        mensageiro.sendMessage( "123456789!" );
    }
    
    
    
}
