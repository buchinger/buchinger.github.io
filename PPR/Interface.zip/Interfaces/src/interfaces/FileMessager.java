/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

/**
 * @author UDESC
 */
public class FileMessager implements Messenger {

    @Override
    public boolean sendMessage(String message) {
        PrintWriter writer;
        try {
            writer = new PrintWriter("messages.txt", "UTF-8");
            writer.println("Message Received: "+message);
            writer.close();
        } catch (FileNotFoundException ex) {
            System.out.println("Erro ao abrir arquivo");
            return false;
        } catch (UnsupportedEncodingException ex) {
            System.out.println("Erro de Codificação não suportada");
            return false;
        }
        
        return true;
    }
    
}
