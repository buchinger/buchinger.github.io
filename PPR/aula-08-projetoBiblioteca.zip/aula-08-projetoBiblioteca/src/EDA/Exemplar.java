package EDA;

public class Exemplar {
    private final int nseq;
    private String observacao;
    private final Livro livro;
    
    public Exemplar( Livro liv, int seq, String obs ){
        livro = liv;
        nseq = seq;
        observacao = obs;
    }
    
    public void atualizarObservacao( String obs ){
        observacao = obs;
    }

    /**
     * @return the nseq
     */
    public int getNseq() {
        return nseq;
    }

    /**
     * @return the observacao
     */
    public String getObservacao() {
        return observacao;
    }

    /**
     * @return the livro
     */
    public Livro getLivro() {
        return livro;
    }
}
