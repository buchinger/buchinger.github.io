package exemploCamadas.apresentacao;
import exemploCamadas.Negocio.NegocioFacade;

// A senha é udesc (criptografada)

public class Main {
    static NegocioFacade negocio = new NegocioFacade();
    public final static String ADM_LOGIN = "admin";    
    public final static String ADM_PASSWORD = "FCE5DE4D28CD57202C019279BCA4B8B336E8A3F7EC30DE04E56CF84993F2CEC5";
    
    private static TelaLogin      tela_login;
    private static TelaOpcoes     tela_opcoes;
    private static TelaCadastro   tela_cadastro;
    private static TelaConsultar  tela_consultar;
    private static TelaListar     tela_listar;
    private static TelaExcluir    tela_excluir;
    
    
    public static void main(String args[]){
        tela_login = new TelaLogin();
        tela_login.setVisible(true);
        tela_login.setLocationRelativeTo(null); // Para centralizar a tela de login 
    }
    
    
    public static void goLogin2Opcoes(){
        tela_login.dispose();
        tela_opcoes = new TelaOpcoes();
        tela_opcoes.setVisible(true);
        tela_opcoes.setLocationRelativeTo(null);
    }
    
    public static void goOpcoes2Cadastro(){
        tela_opcoes.setVisible( false );
        tela_cadastro = new TelaCadastro();
        tela_cadastro.setVisible(true);
        tela_cadastro.setLocationRelativeTo(null);
    }
    
    public static void goCadastro2Opcoes(){
        tela_cadastro.dispose();
        tela_opcoes.setVisible(true);
    }
    
    public static void goOpcoes2Consultar(){
        tela_opcoes.setVisible( false );
        tela_consultar = new TelaConsultar();
        tela_consultar.setVisible(true);
        tela_consultar.setLocationRelativeTo(null);
    }
    
    public static void goConsultar2Opcoes(){
        tela_consultar.dispose();
        tela_opcoes.setVisible(true);
    }
    
    public static void goOpcoes2Listar(){
        tela_opcoes.setVisible( false );
        tela_listar = new TelaListar();
        tela_listar.setVisible(true);
        tela_listar.setLocationRelativeTo(null);
    }
    
    public static void goListar2Opcoes(){
        tela_listar.dispose();
        tela_opcoes.setVisible(true);
    }
    
    
    public static void goOpcoes2Excluir(){
        tela_opcoes.setVisible( false );
        tela_excluir = new TelaExcluir();
        tela_excluir.setVisible(true);
        tela_excluir.setLocationRelativeTo(null);
    }
    
    public static void goExcluir2Opcoes(){
        tela_excluir.dispose();
        tela_opcoes.setVisible(true);
    }
    
}
