/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemploCamadas.ED;

public class Pessoa {
    private long cpf;
    private String nome;
    private int idade;
    private float imc;
    
    public Pessoa(long id, String n, int i, float x){
        cpf = id;
        nome = n;
        idade = i;
        imc = x;
    }
    
    public Pessoa(String serializado){
        String[] campos = serializado.split("\n");
        cpf = Long.parseLong( campos[0] );
        nome = campos[1];
        idade = Integer.parseInt( campos[2] );
        imc = Float.parseFloat( campos[3] );
    }

    
    public String serializar(){
        return cpf +"\n"+ nome +"\n"+ idade +"\n"+ imc +"\n\n";
    }
    
    
    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the idade
     */
    public int getIdade() {
        return idade;
    }

    /**
     * @param idade the idade to set
     */
    public void setIdade(int idade) {
        this.idade = idade;
    }

    /**
     * @return the imc
     */
    public float getImc() {
        return imc;
    }

    /**
     * @param imc the imc to set
     */
    public void setImc(float imc) {
        this.imc = imc;
    }

    /**
     * @return the cpf
     */
    public long getCpf() {
        return cpf;
    }

    /**
     * @param cpf the cpf to set
     */
    public void setCpf(long cpf) {
        this.cpf = cpf;
    }
}
