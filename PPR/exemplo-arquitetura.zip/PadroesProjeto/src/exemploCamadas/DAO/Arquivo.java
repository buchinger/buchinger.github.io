package exemploCamadas.DAO;

import exemploCamadas.ED.Pessoa;
import exemploCamadas.ED.Util;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Arquivo implements DAOFacade {
    private final static String FILE_NAME = "dados-clientes.txt";
    File banco_dados;
    BufferedReader leitor;
    FileWriter escritor;
    
    
    public Arquivo(){
        banco_dados = new File( FILE_NAME );
    }
    
    
    @Override
    public boolean inserirPessoa(Pessoa p) {
        try {
            escritor = new FileWriter(banco_dados, true);
            escritor.write( p.serializar() );
            escritor.close();
        } catch (IOException ex) {
            System.err.println( ex );
            return false;
        }
        return true;
    }

    
    @Override
    public Pessoa consultarPessoa(long cpf) {
        Pessoa cliente = null;
        try {
            FileReader leitor = new FileReader( banco_dados );
            BufferedReader leitor_registro = new BufferedReader( leitor );
            while( true ){
                String serializado = leitor_registro.readLine();
                if( serializado == null ) break;
                
                for(int i=0; i<4; i++)
                    serializado += ("\n" + leitor_registro.readLine());
                
                cliente = new Pessoa(serializado);
                if( cliente.getCpf() == cpf ) break;
            }
            leitor.close();
        } catch (IOException ex) {
            System.err.println( ex );
        }
        return cliente;
    }
    
    
    @Override
    public List<Pessoa> getPessoas(){
        List<Pessoa> clientes = new ArrayList<Pessoa>();
        try {
            FileReader leitor = new FileReader( banco_dados );
            BufferedReader leitor_registro = new BufferedReader( leitor );
            while( true ){
                String serializado = leitor_registro.readLine();
                if( serializado == null ) break;
                
                for(int i=0; i<4; i++)
                    serializado += ("\n" + leitor_registro.readLine());
                
                clientes.add( new Pessoa(serializado) );
            }
            leitor.close();
        } catch (IOException ex) {
            System.err.println( ex );
        }
        return clientes;
    }
    

    @Override
    public boolean removerPessoa(long cpf) {
        return Util.removeLineFromFile( FILE_NAME, String.valueOf(cpf), 4 );
    }
    
}
