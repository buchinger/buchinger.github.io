/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemploCamadas.DAO;

import exemploCamadas.ED.Pessoa;
import java.util.ArrayList;
import java.util.List;

public class Memoria implements DAOFacade {
    ArrayList<Pessoa> pessoas = new ArrayList<>();
    
    @Override
    public boolean inserirPessoa(Pessoa p) {
        boolean result = pessoas.add( p );
        return result;
    }

    @Override
    public Pessoa consultarPessoa(long cpf) {
        for( Pessoa p : pessoas ){
            if( p.getCpf() == cpf )
                return p;
        }
        return null;
    }
    
    @Override
    public List<Pessoa> getPessoas(){
        return pessoas;
    }
    

    @Override
    public boolean removerPessoa(long cpf) {
        for( int i=0; i<pessoas.size(); i++){
            if( pessoas.get(i).getCpf() == cpf ){
                pessoas.remove( i );
                return true;
            }   
        }
        return false;
    }
    
}
