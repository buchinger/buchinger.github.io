package exemploCamadas.Negocio;
import exemploCamadas.ED.Pessoa;

/**
 * @author UDESC
 */
class Academia {
    
    static boolean validarPessoa(Pessoa p){
        // Precisamos verificar, por causa de uma regra de negócio,
        // que a idade não pode ser superior a 99 anos ou inferior a 10 anos
        // e o imc da pessoa deve estar entre 15 e 40
        if( p.getIdade() > 99 && p.getIdade() > 10 && p.getImc() > 15 && p.getImc()<40 )
            return false;
        return true;
    }
    
}
