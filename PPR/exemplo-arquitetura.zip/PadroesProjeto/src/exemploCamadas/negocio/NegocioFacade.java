package exemploCamadas.Negocio;
import exemploCamadas.DAO.DAOFacade;
import exemploCamadas.DAO.Memoria;
import exemploCamadas.DAO.Arquivo;
import exemploCamadas.ED.Pessoa;
import java.util.List;

public class NegocioFacade {
    private final DAOFacade dao = new Arquivo();
    
    // realize uma verificação de controle e redireciona o método.
    public boolean inserirPessoa(Pessoa p) {
        if( Academia.validarPessoa( p ) )
            return dao.inserirPessoa( p );
        return false;
    }

    
    // realiza apenas o redirecionamento do método
    public Pessoa consultarPessoa(long cpf) {
        return dao.consultarPessoa( cpf );
    }
    
    
    // realiza apenas o redirecionamento do método
    public List<Pessoa> getPessoas(){
        return dao.getPessoas();
    }

    
    // realiza apenas o redirecionamento do método
    public boolean removerPessoa(long cpf) {
        return dao.removerPessoa(cpf);
    }
}
