package ExemploFacade;
import ExemploFacade.Messenger.*;
import java.util.Iterator;
import java.util.List;
import javax.swing.JOptionPane;

/**
 * @author UDESC
 */
public class Aplicacao {

    public static void main(String[] args) {
        Facade facade = new MessengerArquivo();
        facade.enviarMensagem("Ola tudo bem?", "Joaozinho Snow");
        facade.enviarMensagem("Tudo. Quando partiremos para o Castle Black?", "Samuel el Wise");
        facade.enviarMensagem("Assim que a Dani Tagarelians preparar o dragonite.", "Joaozinho Snow");
        
        String log_conversas = "";
        List<String> backup = facade.getMensagensEnviadas();
        Iterator it = backup.iterator();
        while( it.hasNext() ){
            log_conversas += it.next() + "\n";
        }
        
        JOptionPane.showMessageDialog(null, log_conversas, "Conversas Sigilosas", JOptionPane.INFORMATION_MESSAGE);       
    }
    
}
