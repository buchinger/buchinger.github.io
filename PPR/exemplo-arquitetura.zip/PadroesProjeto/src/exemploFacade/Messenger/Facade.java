package ExemploFacade.Messenger;

import java.util.List;

/**
 * @author UDESC
 */
public interface Facade {
    public void enviarMensagem(String mensagem, String autor);
    public List<String> getMensagensEnviadas();
}
