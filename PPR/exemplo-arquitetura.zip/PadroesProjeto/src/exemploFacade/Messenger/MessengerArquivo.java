package ExemploFacade.Messenger;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.util.LinkedList;
import java.util.List;

/**
 * @author UDESC
 */
public class MessengerArquivo implements Facade {
    
    @Override
    public void enviarMensagem(String mensagem, String autor){
        LocalDateTime agora = LocalDateTime.now();
        String registro = agora + " - " + autor + " diz: " + mensagem  + "\n";
        File arquivo = new File( "mensagens.txt" );
        try {
            FileWriter escritor = new FileWriter( arquivo, true );
            PrintWriter escritor_arquivo = new PrintWriter( escritor );
            escritor_arquivo.write( registro );
            escritor.close();
        } catch (IOException ex) {
            System.err.println("Não foi possível escrever no arquivo de log!");
        }
    }
    
    
    @Override
    public List<String> getMensagensEnviadas(){
        LinkedList<String> mensagens = new LinkedList();
        File arquivo = new File( "mensagens.txt" );
        FileReader leitor;
        try {
            leitor = new FileReader( arquivo );
            BufferedReader leitor_linha = new BufferedReader( leitor );
            while( true ){
                String mensagem = leitor_linha.readLine();
                if( mensagem == null ) break;
                mensagens.add( mensagem );
            }
            leitor.close();
        } catch (IOException ex) {
            System.err.println("Não foi possível escrever no arquivo de log!");
        }
        return mensagens;
    }
}
