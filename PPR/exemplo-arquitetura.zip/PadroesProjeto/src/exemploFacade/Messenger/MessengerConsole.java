package ExemploFacade.Messenger;

import java.util.ArrayList;
import java.util.List;

/**
 * @author UDESC
 */
public class MessengerConsole implements Facade{
    ArrayList<String> mensagens = new ArrayList();
    
    @Override
    public void enviarMensagem(String mensagem, String autor){
        String registro = autor + " diz: " + mensagem;
        System.out.println( registro );
        mensagens.add( registro );
    }
    
    @Override
    public List<String> getMensagensEnviadas(){
        return mensagens;
    }

}
