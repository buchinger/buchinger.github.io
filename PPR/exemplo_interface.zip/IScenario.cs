﻿using UnityEngine;
using System.Collections;

/// <summary> NOTE: When implementing this interface, remember that a scenario must have at least the same
/// number of textfacts (defined in Definitions [=50]) </summary>
public interface IScenario {

	Vector3			getTeleportPosition(int period);
	ObjectPosition  getStartPosition(uint id);
	ObjectPosition  getFactLocation(uint period, uint id);
	ObjectPosition	getCuriosityLocation(uint period, uint id);
	DepositPosition getDepositLocation(uint period, uint id);

	Texture getMap();
	/// <summary> Calculates the map width proportional to the given map height </summary>
	/// <param name="height"> Height </param>
	float getMapProportionalWidth(float height);
	/// <summary> Calculate and return the proportion between screen map and full size original map </summary>
	/// <param name="height"> The screen's map height. </param>
	float getMapProportion(float height);
	/// <summary> Gets the sizes of the map marker objects (player, unknown object, fact and deposit. </summary>
	/// <param name="avatar"> This var will receive the avatar size </param>
	/// <param name="avatar"> This var will receive the unknown object size (yellow area) </param>
	/// <param name="avatar"> This var will receive the fact size</param>
	/// <param name="avatar"> This var will receive the deposit marker size </param>
	void getMapMarkersSize( ref int avatar, ref int unknown, ref int fact, ref int deposit );
	/// <summary> Converts a scenario position (x,y,z) to a map coordinate </summary>
	/// <param name="positions"> The player position on the real scenario. </param>
	/// <param name="mapPos"> The player position on the full (original size) map scenario. </param>
	void getMapCoordinate(Vector3 positions, ref Vector2 mapPos);

	void raffleContentPositions( ref Content[][][] content, ref CuriosityObject[][] curiosities );
	/// <summary> Each class that implements IScenario could perform updates in game like
	/// the MonoBehaviour function update. It should be call on a update function that
	/// controls the gameplay </summary>
	/// <param name="period"> Indicates the current period in game </param> 
	void update( int period );
	/// <summary> Each class that implements IScenario could use this method to initialize
	/// variables and references in order to be used in the function update improving the
	/// performance. </summary>
	void init();
}
