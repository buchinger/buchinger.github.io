﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class JardimEstanislau : IScenario {

	private bool isTutorial = false;

	//==============================================================================
	//============================= PROCEDURES REGARDING TO THE MAP
	//==============================================================================
	private static Texture map = (Texture) Resources.Load("Map/estanislau");
	const int XSIZE = 1568;
	const int YSIZE = 1263;
	const int PLAYER_MARKER_SIZE  =  80;
	const int OBJECT_MARKER_SIZE  =  85;
	const int FACT_MARKER_SIZE    =  60;
	const int DEPOSIT_MARKER_SIZE =  60;

	public Texture getMap(){ return map; }
	public float getMapProportionalWidth(float height){ return XSIZE * height / YSIZE; 	}
	public float getMapProportion(float height){ 		return height / YSIZE; 			}
	public void getMapMarkersSize( ref int avatar, ref int unknown, ref int fact, ref int deposit ){
		avatar = PLAYER_MARKER_SIZE;
		unknown = OBJECT_MARKER_SIZE;
		fact = FACT_MARKER_SIZE;
		deposit = DEPOSIT_MARKER_SIZE;
	}

	// Mark points (used as reference)
	// road intersection between 1st, 2nd and 4th period
	private const float xRealScenario =  6.52f;
	private const float zRealScenario = 69.86f;
	private const float xMap = 377;
	private const float yMap = 833;

	// distance between the x point and road intersection between 2nd and 3th period
	// (x,z) = ( 506.21 , -344.35)
	// (x,y) = (1060    ,   22   )
	private const float xDiffRealScenario =  499.69f;
	private const float zDiffRealScenario = -414.21f;
	private const float xDiffMap =  683;
	private const float yDiffMap = -811;
	
	public void getMapCoordinate( Vector3 position, ref Vector2 posMap ){
		posMap.x = (((position.z-zRealScenario)*xDiffMap) / zDiffRealScenario) + xMap;
		posMap.y = (((position.x-xRealScenario)*yDiffMap) / xDiffRealScenario) + yMap;
	}





	//==============================================================================
	//==============================================================================
	const uint PERIODS = 4;

	static uint[] FactsLocation    		= new uint[]{ 0,14,21,22,25 }; // index = period
	static uint[] DepositsLocation		= new uint[]{ 0,14,20,27,30 }; // index = period
	static uint[] CuriositiesLocation 	= new uint[]{ 0, 7,12,17,24 }; // index = period

	GameObject avatar;

	// References for Period Colliders (blocks areas from each period)
	GameObject[] colliders_period = new GameObject[ PERIODS-1 ];
	static bool[] flag_colliders = {false, false, false};

	// Variables and References for STATION
	const int STATION_SECTORS = 2;
	GameObject[] station = new GameObject[ STATION_SECTORS ];
	static float[] render_dist_station = new float[] { 50f, 75f };
	static bool[] flag_render_station = new bool[ STATION_SECTORS ];

	// Variables and References for SHANTY HOUSES
	const int SHANTY_HOUSES = 4;
	GameObject[] shanty_house = new GameObject[ SHANTY_HOUSES ];
	static float render_dist_shanty_house = 75f;
	static bool[] flag_render_shanty_house = new bool[ SHANTY_HOUSES ];
	
	// Variables and References for PARK
	const int PARK_SECTORS = 10;
	GameObject[] park = new GameObject[ PARK_SECTORS ];
	static float render_dist_park = 200f;
	static bool[] flag_render_park = new bool[ PARK_SECTORS ];

	// Variables and References for GRAVEYARD
	const int GRAVEYARD_SECTORS = 7;
	GameObject[] graveyard = new GameObject[ GRAVEYARD_SECTORS ];
	static float[] render_dist_graveyard = new float[] { 300f,300f,300f, 250f,250f,250f,250f }; //[Entrance-Left, Entrance-Right, Rocks-Left, Tomb-Sector-1, Tomb-Sector-2, Tomb-Sector-3, Tomb-Sector-4]
	static bool[] flag_render_graveyard = new bool[ GRAVEYARD_SECTORS ];

	// Variables and References for BUILDING
	const int BUILDING_SECTORS = 9;
	GameObject[] building = new GameObject[ BUILDING_SECTORS ];
	static float render_dist_building = 75f;
	static bool flag_render_building;

	// Variables and References for STREET OBJECTS
	const int STREET_INTERSECTIONS = 5;
	GameObject[] street_intersection = new GameObject[ STREET_INTERSECTIONS ];
	static float render_dist_signs = 100f;
	static bool[] flag_render_street_intersections = new bool[ STREET_INTERSECTIONS ];

	// Variables and References for STREET LAMPS
	const int STREET_LAMPS = 22;
	GameObject[] street_lamp = new GameObject[ STREET_LAMPS ];
	static float render_dist_street_lamps = 150f;
	static bool[] flag_render_street_lamps = new bool[ STREET_LAMPS ];

	// Variables and References for STREET CONES
	const int STREET_CONES = 4;
	GameObject[] street_cone = new GameObject[ STREET_CONES ];
	static float render_dist_street_cones = 100f;
	static bool[] flag_render_street_cones = new bool[ STREET_CONES ];






	/// <summary> Creates a list of numbers from 0 to the length of facts or deposits position array </summary>
	/// <param name="period"> The game period (phase) </param>
	/// <param name="obj"> A character that indicates which arrat length should be consider: 'f'=factsPositions / 'd'=depositsPosition </param>
	private static List<uint> getPositionList(uint period, char obj){
		List<uint> list = new List<uint>();
		switch( obj ){
			case 'f': //fact
				for(uint i=0; i<FactsLocation[ period ]; i++)
					list.Add( i );
				break;
			case 'd': //deposit
				for(uint i=0; i<DepositsLocation[ period ]; i++)
					list.Add( i );
				break;
			case 'c': //curiosity
				for(uint i=0; i<CuriositiesLocation[ period ]; i++)
					list.Add( i );
				break;
		}
		return list;
	}







	//=================================================================================================//
	//=================================================================================================//
	//============================        INTERFACE IMPLEMENTATION        =============================//

	
	//===================================================================================================//
	/// <summary> Procedure call for initializing variables or references related to the scenario </summary>
	public void init(){
		// checks if the player is playing the tutorial
		if( Application.loadedLevelName.Equals( Definitions.tutorial_level ) )
			isTutorial = true;
		else
			isTutorial = false;


		avatar = GameObject.Find ("avatar-"+Definitions.id);

		//=== COLLIDERS
		for(uint i=0; i<PERIODS-1; i++){
			colliders_period[i] = GameObject.Find ("Collider-Period-"+(i+2));
			flag_colliders[i] = false;
		}


		//=== HOUSES
		/*GameObject houses = GameObject.Find ("Houses");
		houses.SetActive( false );
		houses.GetComponent<CombineChildren>().enabled = true;
		houses.SetActive( true );
		*/

		//=== STATION
		for(uint i=0; i<STATION_SECTORS; i++)
			flag_render_station[i] = true;
		station[0] = GameObject.Find ("Station-Interior-1F");
		station[1] = GameObject.Find ("Station-Flowers");
		for(uint i=1; i<STATION_SECTORS; i++)
			flag_render_station[i] = true;
		// Desactivate 0F objetcs because it is controlled by a LOD sensor in Station-Interior-0F
		GameObject.Find ("Station-Interior-0F-Objects").SetActive( false );


		//=== SHANTY HOUSES
		shanty_house[0] = GameObject.Find ("SH-1-Interior");
		shanty_house[1] = GameObject.Find ("SH-2-Interior");
		shanty_house[2] = GameObject.Find ("SH-3-Interior");
		shanty_house[3] = GameObject.Find ("SH-4-Interior");
		for(uint i=0; i<SHANTY_HOUSES; i++)
			flag_render_shanty_house[i] = true;
		/* I Think I fixed it!!! (in the blender model)
		// For an unknow reason when combining the meshes of shanty houses exterior the normals are
		// being inverted so we have to solve this...
		Toolbox.ChangeNormals( GameObject.Find ("SH-Structure") );
		*/


		//=== PARK
		park[0] = GameObject.Find ("Park-Entrance-South");
		park[1] = GameObject.Find ("Park-Entrance-Southwest");
		park[2] = GameObject.Find ("Park-Entrance-West");
		park[3] = GameObject.Find ("Park-Entrance-Northwest");
		park[4] = GameObject.Find ("Park-Entrance-North");
		park[5] = GameObject.Find ("Park-Entrance-Northeast");
		park[6] = GameObject.Find ("Park-Entrance-East");
		park[7] = GameObject.Find ("Park-Sector-South");
		park[8] = GameObject.Find ("Park-Sector-Southwest");
		park[9] = GameObject.Find ("Park-Sector-Center");
		for(uint i=0; i<PARK_SECTORS; i++)
			flag_render_park[i] = true;

		//=== GRAVEYARD
		if( !isTutorial ){
			graveyard[0] = GameObject.Find ("Entrance-Sector-Left");
			graveyard[1] = GameObject.Find ("Entrance-Sector-Right");
			graveyard[2] = GameObject.Find ("Rocks-Left");
			graveyard[3] = GameObject.Find ("Tomb-Sector-1");
			graveyard[4] = GameObject.Find ("Tomb-Sector-2");
			graveyard[5] = GameObject.Find ("Tomb-Sector-3");
			graveyard[6] = GameObject.Find ("Tomb-Sector-4");
			for(uint i=0; i<GRAVEYARD_SECTORS; i++)
				flag_render_graveyard[i] = true;
			for(uint i=0; i<2; i++){
				graveyard[i].SetActive( false );
				graveyard[i].GetComponent<CombineChildren>().enabled = true;
				graveyard[i].SetActive( true );
			}
		}

		//=== BUILDING (most of them are controlled by collider triggers)
		if( !isTutorial ){
			building[0] = GameObject.Find ("GateKeeper");
			building[1] = GameObject.Find ("AP01-Objects");
			building[2] = GameObject.Find ("AP11-Objects");
			building[3] = GameObject.Find ("AP12-Objects");
			building[4] = GameObject.Find ("AP21-Objects");
			building[5] = GameObject.Find ("AP22-Objects");
			building[6] = GameObject.Find ("AP31-Objects");
			building[7] = GameObject.Find ("AP32-Objects");
			building[8] = GameObject.Find ("AP41-Objects");
			flag_render_building = true;
			for(uint i=1; i<BUILDING_SECTORS; i++){
				building[i].SetActive( true ); //not sure if when the scenario is loaded the combine children is activated even if the gameobject is not active.... so we do this
				building[i].SetActive( false );
			}
		}

		//=== STREET INTERSECTION
		street_intersection[0] = GameObject.Find ("Intersection-1");
		street_intersection[1] = GameObject.Find ("Intersection-2");
		street_intersection[2] = GameObject.Find ("Intersection-3");
		street_intersection[3] = GameObject.Find ("Intersection-4");
		street_intersection[4] = GameObject.Find ("Intersection-5");
		for(uint i=0; i<STREET_INTERSECTIONS; i++)
			flag_render_street_intersections[i] = true;

		//=== STREET LAMPS
		for(uint i=1; i<=STREET_LAMPS; i++){
			uint j = i-1;
			street_lamp[j] = GameObject.Find ("Street-Lamp-"+i);
			flag_render_street_lamps[j] = true;
		}

		//=== STREET CONES
		for(uint i=1; i<=STREET_CONES; i++){
			uint j = i-1;
			street_cone[j] = GameObject.Find ("Cone-Group-"+i);
			flag_render_street_cones[j] = true;
		}

	}



	//===================================================================================================//
	/// <summary> Procedure call in each update during game. In this case, this method is used to reduce
	///   game rendering objects since distance objects will not be seen be player, then they could be
	///   not rendered </summary>
	public void update( int period ){

		// If it is a new period remove the colliders!!
		if( period > 1 && flag_colliders[ period-2 ]==false ){
			colliders_period[ period-2 ].SetActive( false );
			flag_colliders[ period-2 ] = true;
		}

		//Renderer[] renderers;
		//Debug.Log (Vector3.Distance (station [2].transform.position, avatar.transform.position));
		//Debug.Log ( station[2].transform.position );

		//===== Show/Hide Station Furniture
		// for each STATION sector (group of objects in station geografically next to each other)
		// [except the station0F that is controlled by collider triggers]
		for(uint index=0; index<STATION_SECTORS; index++){
			if( Vector3.Distance( station[index].transform.position, avatar.transform.position ) > render_dist_station[index] ){
				if( flag_render_station[index] ){ // if station interior was being rendered then hide it
					station[index].SetActive( false );
					/*renderers = station[index].GetComponentsInChildren<Renderer>();
					foreach( Renderer r in renderers )
						r.enabled = false;
					*/
					flag_render_station[index] = false;
				}
			}
			else{
				if( !flag_render_station[index] ){ // if station interior was not being renderer then do it
					station[index].SetActive( true );
					/*renderers = station[index].GetComponentsInChildren<Renderer>();
					foreach( Renderer r in renderers )
						r.enabled = true;
					 */
					flag_render_station[index] = true;
				}
			}
		}


		//===== Show/Hide Shanty House's Objects
		for(uint index=0; index<SHANTY_HOUSES; index++){ // for each Shanty House
			if( Vector3.Distance( shanty_house[index].transform.position, avatar.transform.position ) > render_dist_shanty_house ){
				if( flag_render_shanty_house[index] ){ // if shanty house's objects was being rendered then hide it
					shanty_house[index].SetActive( false );
					flag_render_shanty_house[index] = false;
				}
			}
			else{
				if( !flag_render_shanty_house[index] ){ // if shanty house's objects was not being renderer then do it
					shanty_house[index].SetActive( true );
					flag_render_shanty_house[index] = true;
				}
			}
		}


		//===== Show/Hide Park Objects
		for(uint index=0; index<PARK_SECTORS; index++){ // for each park sector (group of park objects geografically next to each other)
			if( Vector3.Distance( park[index].transform.position, avatar.transform.position ) > render_dist_park ){
				if( flag_render_park[index] ){ // if park objects was being rendered then hide it
					park[index].SetActive( false );
					flag_render_park[index] = false;
				}
			}
			else{
				if( !flag_render_park[index] ){ // if park objects was not being renderer then do it
					park[index].SetActive( true );
					flag_render_park[index] = true;
				}
			}
		}


		//===== Show/Hide Graveyard Objects
		if( !isTutorial ){
			for(uint index=0; index<GRAVEYARD_SECTORS; index++){ // for each graveyard sector (group of graveyard objects geografically next to each other)
				if( Vector3.Distance( graveyard[index].transform.position, avatar.transform.position ) > render_dist_graveyard[index] ){
					if( flag_render_graveyard[index] ){ // if graveyard objects was being rendered then hide it
						graveyard[index].SetActive( false );
						flag_render_graveyard[index] = false;
					}
				}
				else{
					if( !flag_render_graveyard[index] ){ // if graveyard objects was not being renderer then do it
						graveyard[index].SetActive( true );
						flag_render_graveyard[index] = true;
					}
				}
			}
		}


		//===== Show/Hide Building Objects
		if( !isTutorial ){
			// There is only one building sector to check by distance (the others are controlled by collider triger)
			if( Vector3.Distance( building[0].transform.position, avatar.transform.position ) > render_dist_building ){
				if( flag_render_building ){ // if building objects was being rendered then hide it
					building[0].SetActive( false );
					flag_render_building = false;
				}
			}
			else{
				if( !flag_render_building ){ // if building objects was not being renderer then do it
					building[0].SetActive( true );
					flag_render_building = true;
				}
			}
		}


		//===== Show/Hide Street Intersection Objects
		for(uint index=0; index<STREET_INTERSECTIONS; index++){ // for each street intersection (group of signs next to each other)
			if( Vector3.Distance( street_intersection[index].transform.position, avatar.transform.position ) > render_dist_signs ){
				if( flag_render_street_intersections[index] ){ // if street intersection objects was being rendered then hide it
					street_intersection[index].SetActive( false );
					flag_render_street_intersections[index] = false;
				}
			}
			else{
				if( !flag_render_street_intersections[index] ){ // if street intersection objects was not being renderer then do it
					street_intersection[index].SetActive( true );
					flag_render_street_intersections[index] = true;
				}
			}
		}


		//===== Show/Hide Street Lamps
		for(uint index=0; index<STREET_LAMPS; index++){ // for each street lamp
			if( Vector3.Distance( street_lamp[index].transform.position, avatar.transform.position ) > render_dist_street_lamps ){
				if( flag_render_street_lamps[index] ){ // if street lamp object was being rendered then hide it
					street_lamp[index].SetActive( false );
					flag_render_street_lamps[index] = false;
				}
			}
			else{
				if( !flag_render_street_lamps[index] ){ // if street lamp object was not being renderer then do it
					street_lamp[index].SetActive( true );
					flag_render_street_lamps[index] = true;
				}
			}
		}


		//===== Show/Hide Street Cones
		for(uint index=0; index<STREET_CONES; index++){ // for each street cone group
			if( Vector3.Distance( street_cone[index].transform.position, avatar.transform.position ) > render_dist_street_cones ){
				if( flag_render_street_cones[index] ){ // if street cone objects was being rendered then hide it
					street_cone[index].SetActive( false );
					flag_render_street_cones[index] = false;
				}
			}
			else{
				if( !flag_render_street_cones[index] ){ // if street cone object was not being renderer then do it
					street_cone[index].SetActive( true );
					flag_render_street_cones[index] = true;
				}
			}
		}



	}




	

	/// <summary> Contains the positions/orientations where the players could start the game </summary>
	public ObjectPosition getStartPosition( uint id ){
		ObjectPosition pos = new ObjectPosition( new Vector3(-215f , 18f, 70f), Quaternion.Euler(0f, 90f, 0f) );
		switch( id ){
			case 0:
			pos = new ObjectPosition( new Vector3(-210f , 17f, 75f), Quaternion.Euler(0f, 90f, 0f) );
			break;

			case 1:
			pos = new ObjectPosition( new Vector3(-210f , 17f, 71.6f), Quaternion.Euler(0f, 90f, 0f) );
			break;

			case 2:
			pos = new ObjectPosition( new Vector3(-210f , 17f, 68.3f), Quaternion.Euler(0f, 90f, 0f) );
			break;

			case 3:
			pos = new ObjectPosition( new Vector3(-210f , 17f, 65f), Quaternion.Euler(0f, 90f, 0f) );
			break;
		}
		return pos;
	}






	
	/// <summary> Contains the positions/orientations where the players could teleport (when stuck) during the game </summary>
	public Vector3 getTeleportPosition( int period ){
		Vector3 pos = new Vector3(0, 30, 0);
		switch( period ){
		case 1:
			pos = new Vector3(-172 , 14 ,   86);
			break;
		case 2:
			pos = new Vector3( 203 , 12 ,   70);
			break;
		case 3:
			pos = new Vector3( 295 , 22 , -354);
			break;
		case 4:
			pos = new Vector3( -35 , 12 ,  -92);
			break;
		}
		return pos;
	}







	//================================================================================================//
	//================================================================================================//
	/// <summary> Raffles the content positions for a game and put the result in the multi dimensional array content.
	/// OBS: the 'content' array should be already initiallized </summary>
	/// <param name="content"> A multi dimensional array with game content meta data </param>
	public void raffleContentPositions( ref Content[][][] content, ref CuriosityObject[][] curiosities ){
		uint n_facts, n_curi;
		int n1, n2;

		for(uint period=1; period<=Definitions.PERIODS; period++){ // for each period in the game the system chooses the fact ids
			List<uint> raffle_list_fact      = getPositionList( period, 'f' ); // create a raffle list with fact positions id available
			List<uint> raffle_list_deposit   = getPositionList( period, 'd' ); // create a raffle list with deposit positions id available
			List<uint> raffle_list_curiosity = getPositionList( period, 'c' ); // create a raffle list with curiosity positions id available

			// Raffles fact texts and questions positions
			for(TextFacts.Difficulty difficulty=TextFacts.Difficulty.Easy; difficulty<=TextFacts.Difficulty.Hard_Multiple; difficulty++){ // for each fact difficulties
				n_facts = Definitions.game_facts[ period ][ (uint) difficulty ];
				//Debug.Log("n_facts: "+n_facts);
				//Debug.Log("raffle_list_facts: "+raffle_list_fact.Count);
				//Debug.Log("raffle_list_depos: "+raffle_list_deposit.Count);

				for( uint i=0; i < n_facts; i++ ){ // perform the raffle
					if( period==1 && difficulty==TextFacts.Difficulty.Easy && i==0 ) //special case (the first fact will be always inside the station
						n1 = 13;
					else
						n1 = Random.Range( 0,raffle_list_fact.Count );
					n2 = Random.Range( 0,raffle_list_deposit.Count );
					//Debug.Log("n1["+i+"]: ("+n1+") => "+raffle_list_fact[n1]);
					//Debug.Log("n2["+i+"]: ("+n2+") => "+raffle_list_deposit[n2]);
					content[ period ][ (uint) difficulty ][ i ].factPositionId = raffle_list_fact[ n1 ]; // put the fact position id
					content[ period ][ (uint) difficulty ][ i ].questionPositionId = raffle_list_deposit[ n2 ]; // put the question position id
					raffle_list_fact.RemoveAt( n1 );
					raffle_list_deposit.RemoveAt( n2 );
				}
			}

			// Raffles curiosities positions
			n_curi = Definitions.game_curiosities[ period ];
			//Debug.Log("raffle_list_curi: "+raffle_list_curiosity.Count);

			for( uint i=0; i < n_curi; i++ ){ // perform the raffle
				n1 = Random.Range( 0,raffle_list_curiosity.Count );
				//Debug.Log("n1["+i+"]: ("+n1+") => "+raffle_list_curiosity[n1]);
				curiosities[ period ][ i ].CuriosityPositionId = raffle_list_curiosity[ n1 ]; // put the curiosity position id
				raffle_list_curiosity.RemoveAt( n1 );
			}
		}
	}



	//================================================================================================//
	//================================================================================================//
	/// <summary> Cointains the positions/orientation where 'facts' could be placed </summary>
	public ObjectPosition getFactLocation(uint period, uint id){
		ObjectPosition location = new ObjectPosition( Vector3.zero, Quaternion.identity );

		switch( period ){
		
		case 1: // First period
			switch(id){
			case  0: location = new ObjectPosition( new Vector3(  -97.7f ,  8.9f , 103.6f ), Quaternion.Euler( new Vector3( 45, 264,0 )) ); break;
			case  1: location = new ObjectPosition( new Vector3( -177.9f ,   13f ,  94.4f ), Quaternion.Euler( new Vector3( 45, 113,0 )) ); break;
			case  2: location = new ObjectPosition( new Vector3( -185.8f , 10.6f ,   213f ), Quaternion.Euler( new Vector3( 45,   5,0 )) ); break;
			case  3: location = new ObjectPosition( new Vector3( -151.7f , 10.9f , 193.1f ), Quaternion.Euler( new Vector3( 45,  44,0 )) ); break;
			case  4: location = new ObjectPosition( new Vector3( -117.7f , 10.2f , 199.9f ), Quaternion.Euler( new Vector3( 45,   5,0 )) ); break;
			case  5: location = new ObjectPosition( new Vector3( -108.8f , 10.9f , 214.7f ), Quaternion.Euler( new Vector3( 45, 181,0 )) ); break;
			case  6: location = new ObjectPosition( new Vector3(  -79.3f , 10.9f ,   179f ), Quaternion.Euler( new Vector3( 45,  33,0 )) ); break;
			case  7: location = new ObjectPosition( new Vector3(   -5.7f , 10.2f , 131.8f ), Quaternion.Euler( new Vector3( 45, 202,0 )) ); break;
			case  8: location = new ObjectPosition( new Vector3(   -3.6f , 10.6f ,    97f ), Quaternion.Euler( new Vector3( 45, 182,0 )) ); break;
			case  9: location = new ObjectPosition( new Vector3(   -181f , 11.4f , 147.6f ), Quaternion.Euler( new Vector3( 45, 101,0 )) ); break;
			case 10: location = new ObjectPosition( new Vector3(  -47.5f , 10.2f ,  96.4f ), Quaternion.Euler( new Vector3( 45, 177,0 )) ); break;
			case 11: location = new ObjectPosition( new Vector3(   -129f , 10.2f ,  92.2f ), Quaternion.Euler( new Vector3( 45, 178,0 )) ); break;
			case 12: location = new ObjectPosition( new Vector3( -142.9f , 10.1f , 175.1f ), Quaternion.Euler( new Vector3( 45, 168,0 )) ); break;
			case 13: location = new ObjectPosition( new Vector3( -104.5f ,  6.1f , 107.9f ), Quaternion.Euler( new Vector3( 45,-180,0 )) ); break;
			}
			break;

		case 2: // Second period
			switch(id){
			case  0: location = new ObjectPosition( new Vector3( 192.4f , 11.3f ,   13.7f ), Quaternion.Euler( new Vector3(45,  25.6f,0 )) ); break;
			case  1: location = new ObjectPosition( new Vector3( 165.9f , 21.3f , - 89.5f ), Quaternion.Euler( new Vector3(45,  39.8f,0 )) ); break;
			case  2: location = new ObjectPosition( new Vector3( 201.7f , 17.5f , -102.8f ), Quaternion.Euler( new Vector3(45, 252.3f,0 )) ); break;
			case  3: location = new ObjectPosition( new Vector3( 303.4f , 17.5f , -144.8f ), Quaternion.Euler( new Vector3(45,  60.9f,0 )) ); break;
			case  4: location = new ObjectPosition( new Vector3( 447.2f , 16.9f , - 23.4f ), Quaternion.Euler( new Vector3(45,- 86.9f,0 )) ); break;
			case  5: location = new ObjectPosition( new Vector3( 341.2f , 25.8f , - 67.8f ), Quaternion.Euler( new Vector3(45,- 86.9f,0 )) ); break;
			case  6: location = new ObjectPosition( new Vector3( 348.6f , 24.1f , -138.7f ), Quaternion.Euler( new Vector3(45,- 65.6f,0 )) ); break;
			case  7: location = new ObjectPosition( new Vector3( 477.6f , 10.6f , -141.8f ), Quaternion.Euler( new Vector3(45,  64.2f,0 )) ); break;
			case  8: location = new ObjectPosition( new Vector3( 424.0f , 10.3f ,   38.6f ), Quaternion.Euler( new Vector3(45,  33.2f,0 )) ); break;
			case  9: location = new ObjectPosition( new Vector3( 478.9f , 13.0f , -259.4f ), Quaternion.Euler( new Vector3(45,  62.2f,0 )) ); break;
			case 10: location = new ObjectPosition( new Vector3( 344.5f , 21.7f , -196.6f ), Quaternion.Euler( new Vector3(45,   6.8f,0 )) ); break;
			case 11: location = new ObjectPosition( new Vector3( 276.3f , 22.9f , -254.0f ), Quaternion.Euler( new Vector3(45,-  1.9f,0 )) ); break;
			case 12: location = new ObjectPosition( new Vector3( 230.7f , 22.5f , -273.8f ), Quaternion.Euler( new Vector3(45,- 32.1f,0 )) ); break;
			case 13: location = new ObjectPosition( new Vector3( 203.1f , 20.4f , -317.0f ), Quaternion.Euler( new Vector3(45,  94.9f,0 )) ); break;
			case 14: location = new ObjectPosition( new Vector3( 156.9f , 21.6f , -221.8f ), Quaternion.Euler( new Vector3(45,- 11.1f,0 )) ); break;
			case 15: location = new ObjectPosition( new Vector3(  81.4f , 21.7f , -254.7f ), Quaternion.Euler( new Vector3(45, 128.2f,0 )) ); break;
			case 16: location = new ObjectPosition( new Vector3(  34.9f , 18.6f , -276.7f ), Quaternion.Euler( new Vector3(45, 184.2f,0 )) ); break;
			case 17: location = new ObjectPosition( new Vector3(  35.1f , 12.8f , -177.9f ), Quaternion.Euler( new Vector3(45, 300.5f,0 )) ); break;
			case 18: location = new ObjectPosition( new Vector3( 117.1f , 23.2f , -176.8f ), Quaternion.Euler( new Vector3(45, 372.4f,0 )) ); break;
			case 19: location = new ObjectPosition( new Vector3( 242.6f , 18.1f , -196.1f ), Quaternion.Euler( new Vector3(45,     0,0 )) ); break;
			case 20: location = new ObjectPosition( new Vector3( 239.4f , 19.1f , - 90.7f ), Quaternion.Euler( new Vector3(45,-184.7f,0 )) ); break;
			}
			break;

		case 3: // Third period
			switch(id){
			case  0: location = new ObjectPosition( new Vector3( 304.6f , 22.2f , -394.6f ), Quaternion.Euler( new Vector3(45, 323.7f,0 )) ); break;
			case  1: location = new ObjectPosition( new Vector3( 318.1f , 31.5f , -444.1f ), Quaternion.Euler( new Vector3(45,- 93.9f,0 )) ); break;
			case  2: location = new ObjectPosition( new Vector3( 331.3f , 44.3f , -510.4f ), Quaternion.Euler( new Vector3(45,- 93.9f,0 )) ); break;
			case  3: location = new ObjectPosition( new Vector3( 323.9f , 45.6f , -567.2f ), Quaternion.Euler( new Vector3(45,-   94 ,0 )) ); break;
			case  4: location = new ObjectPosition( new Vector3( 223.3f , 45.1f , -593.6f ), Quaternion.Euler( new Vector3(45,   2.1f,0 )) ); break;
			case  5: location = new ObjectPosition( new Vector3( 203.2f , 45.1f , -599.6f ), Quaternion.Euler( new Vector3(45,- 89.6f,0 )) ); break;
			case  6: location = new ObjectPosition( new Vector3( 229.9f , 34.7f , -490.9f ), Quaternion.Euler( new Vector3(45,-  0.1f,0 )) ); break;
			case  7: location = new ObjectPosition( new Vector3( 236.8f , 36.4f , -556.2f ), Quaternion.Euler( new Vector3(45,   2.4f,0 )) ); break;
			case  8: location = new ObjectPosition( new Vector3( 134.3f , 44.1f , -  557f ), Quaternion.Euler( new Vector3(45,  91.4f,0 )) ); break;
			case  9: location = new ObjectPosition( new Vector3( 164.7f , 31.7f , -  480f ), Quaternion.Euler( new Vector3(45,-137.8f,0 )) ); break;
			case 10: location = new ObjectPosition( new Vector3( 225.4f , 30.5f , -432.4f ), Quaternion.Euler( new Vector3(45, 356.4f,0 )) ); break;
			case 11: location = new ObjectPosition( new Vector3( 102.4f , 41.1f , -512.7f ), Quaternion.Euler( new Vector3(45, 272.6f,0 )) ); break;
			case 12: location = new ObjectPosition( new Vector3(  28.6f , 45.7f , -515.9f ), Quaternion.Euler( new Vector3(45, 176.4f,0 )) ); break;
			case 13: location = new ObjectPosition( new Vector3(   -29f , 36.3f , -501.2f ), Quaternion.Euler( new Vector3(45,- 44.2f,0 )) ); break;
			case 14: location = new ObjectPosition( new Vector3(   2.2f , 45.7f , -559.6f ), Quaternion.Euler( new Vector3(45,-  0.7f,0 )) ); break;
			case 15: location = new ObjectPosition( new Vector3(-151.8f ,   37f , -524.5f ), Quaternion.Euler( new Vector3(45,    90 ,0 )) ); break;
			case 16: location = new ObjectPosition( new Vector3( -41.7f , 29.5f , -432.4f ), Quaternion.Euler( new Vector3(45, 337.3f,0 )) ); break;
			case 17: location = new ObjectPosition( new Vector3(   7.7f , 31.7f , -452.1f ), Quaternion.Euler( new Vector3(45,-  0.1f,0 )) ); break;
			case 18: location = new ObjectPosition( new Vector3( 274.2f ,   45f , -596.7f ), Quaternion.Euler( new Vector3(45,     0 ,0 )) ); break;
			case 19: location = new ObjectPosition( new Vector3( 179.7f , 23.7f , -402.2f ), Quaternion.Euler( new Vector3(45,     0 ,0 )) ); break;
			case 20: location = new ObjectPosition( new Vector3( 66.2f ,  38.6f , -471.4f ), Quaternion.Euler( new Vector3(45,  89.2f,0 )) ); break;
			case 21: location = new ObjectPosition( new Vector3( 65.6f ,  27.4f , -409.2f ), Quaternion.Euler( new Vector3(45,     0 ,0 )) ); break;
			}
			break;

		case 4: // Fourth period
			switch(id){
			case  0: location = new ObjectPosition( new Vector3( -47.7f , 10.4f , -193.5f ), Quaternion.Euler( new Vector3(45, 60.4f,0 )) ); break;
			case  1: location = new ObjectPosition( new Vector3( -72.8f , 10.5f , -193.8f ), Quaternion.Euler( new Vector3(45,   90 ,0 )) ); break;
			case  2: location = new ObjectPosition( new Vector3( -76.8f , 15.2f , -193.8f ), Quaternion.Euler( new Vector3(45,   90 ,0 )) ); break;
			case  3: location = new ObjectPosition( new Vector3( -62.8f , 19.3f , -188.7f ), Quaternion.Euler( new Vector3(45,  240 ,0 )) ); break;
			case  4: location = new ObjectPosition( new Vector3( -76.6f ,   24f ,   -194f ), Quaternion.Euler( new Vector3(45,   90 ,0 )) ); break;
			case  5: location = new ObjectPosition( new Vector3( -70.4f , 28.4f , -184.8f ), Quaternion.Euler( new Vector3(45,  240 ,0 )) ); break;
			case  6: location = new ObjectPosition( new Vector3(   -21f ,   11f , -105.6f ), Quaternion.Euler( new Vector3(45,   54 ,0 )) ); break;
			case  7: location = new ObjectPosition( new Vector3( -90.3f ,   11f , -103.4f ), Quaternion.Euler( new Vector3(45,   54 ,0 )) ); break;
			case  8: location = new ObjectPosition( new Vector3(-140.3f ,   11f , -205.8f ), Quaternion.Euler( new Vector3(45,   54 ,0 )) ); break;
			case  9: location = new ObjectPosition( new Vector3(-171.7f ,   11f , -263.3f ), Quaternion.Euler( new Vector3(45,    0 ,0 )) ); break;
			case 10: location = new ObjectPosition( new Vector3(-163.2f ,  9.7f ,  -92.2f ), Quaternion.Euler( new Vector3(45,   90 ,0 )) ); break;
			case 11: location = new ObjectPosition( new Vector3(-152.9f , 11.4f ,  -33.9f ), Quaternion.Euler( new Vector3(45, 82.4f,0 )) ); break;
			case 12: location = new ObjectPosition( new Vector3( -21.7f ,   10f ,  -10.8f ), Quaternion.Euler( new Vector3(45,   90 ,0 )) ); break;
			case 13: location = new ObjectPosition( new Vector3( -58.5f ,   10f ,   47.9f ), Quaternion.Euler( new Vector3(45,    0 ,0 )) ); break;
			case 14: location = new ObjectPosition( new Vector3(-109.1f , 16.0f ,  -45.1f ), Quaternion.Euler( new Vector3(45,220, 0 )) ); break;
			case 15: location = new ObjectPosition( new Vector3(-136.9f , 11.3f , -117.8f ), Quaternion.Euler( new Vector3(45,  0, 0 )) ); break;
			case 16: location = new ObjectPosition( new Vector3( -45.2f , 10.2f ,   28.4f ), Quaternion.Euler( new Vector3(45,-30, 0 )) ); break;
			case 17: location = new ObjectPosition( new Vector3( -51.1f , 10.7f , -118.7f ), Quaternion.Euler( new Vector3(45,-53, 0 )) ); break;
			case 18: location = new ObjectPosition( new Vector3( -78.7f , 10.0f , -187.4f ), Quaternion.Euler( new Vector3(45,  0, 0 )) ); break;
			case 19: location = new ObjectPosition( new Vector3( -51.0f , 10.5f , -187.0f ), Quaternion.Euler( new Vector3(45,180, 0 )) ); break;
			case 20: location = new ObjectPosition( new Vector3(-136.6f , 15.7f , -117.6f ), Quaternion.Euler( new Vector3(45,306, 0 )) ); break;
			case 21: location = new ObjectPosition( new Vector3(-101.2f , 12.4f ,  -55.0f ), Quaternion.Euler( new Vector3(45, 90, 0 )) ); break;
			case 22: location = new ObjectPosition( new Vector3( -65.0f ,  9.9f ,   30.4f ), Quaternion.Euler( new Vector3(45,181,-3 )) ); break;
			case 23: location = new ObjectPosition( new Vector3( -70.2f , 19.8f , -199.1f ), Quaternion.Euler( new Vector3(45,  0, 0 )) ); break;
			case 24: location = new ObjectPosition( new Vector3( -62.7f , 24.1f , -186.0f ), Quaternion.Euler( new Vector3(45,200, 0 )) ); break;
			}
			break;
		}

		return location;
	}


	
	//================================================================================================//
	//================================================================================================//
	/// <summary> Cointains the positions/orientation where 'deposits' could be placed </summary>
	public DepositPosition getDepositLocation(uint period, uint id){
		DepositPosition location = new DepositPosition( Vector3.zero, Quaternion.identity, 0 );

		switch( period ){
			
		case 1: // First period
			switch(id){
			case  0: location = new DepositPosition( new Vector3( -152.01f ,  8.32f , 181.74f ), Quaternion.Euler( new Vector3( -90,  0,  0 )), InteractiveObjects.ObjectType.Deposit_Tires ); break;
			case  1: location = new DepositPosition( new Vector3( - 92.20f ,  8.33f , 229.51f ), Quaternion.Euler( new Vector3( -90,150,  0 )), InteractiveObjects.ObjectType.Deposit_Tires ); break;
			case  2: location = new DepositPosition( new Vector3(   28.07f ,  8.44f ,  96.97f ), Quaternion.Euler( new Vector3( -90,180,  0 )), InteractiveObjects.ObjectType.Deposit_Tires ); break;
			case  3: location = new DepositPosition( new Vector3( -150.62f ,  9.27f , 182.15f ), Quaternion.Euler( new Vector3( -90,  0,  0 )), InteractiveObjects.ObjectType.Deposit_Vase_Empty ); break;
			case  4: location = new DepositPosition( new Vector3( - 96.20f , 12.02f , 219.61f ), Quaternion.Euler( new Vector3(   0,  0,  0 )), InteractiveObjects.ObjectType.Deposit_Water_Box ); break;
			case  5: location = new DepositPosition( new Vector3( - 94.26f ,  9.43f , 215.24f ), Quaternion.Euler( new Vector3(   0,  0,  0 )), InteractiveObjects.ObjectType.Deposit_Flower_Vase_1 ); break;
			case  6: location = new DepositPosition( new Vector3( - 50.54f ,  8.73f , 151.65f ), Quaternion.Euler( new Vector3(   0,  0,-180 )), InteractiveObjects.ObjectType.Deposit_Tire ); break;
			case  7: location = new DepositPosition( new Vector3(   23.63f ,  8.63f , 117.34f ), Quaternion.Euler( new Vector3( -90,  0,  0 )), InteractiveObjects.ObjectType.Deposit_Bucket_Brown ); break;
			case  8: location = new DepositPosition( new Vector3( -187.15f ,  9.70f , 212.06f ), Quaternion.Euler( new Vector3(   0,  0,  0 )), InteractiveObjects.ObjectType.Deposit_Barrel ); break;
			case  9: location = new DepositPosition( new Vector3( -170.77f ,  8.92f , 175.56f ), Quaternion.Euler( new Vector3(   8,-22,  0 )), InteractiveObjects.ObjectType.Deposit_Tire ); break;
			case 10: location = new DepositPosition( new Vector3( -179.00f ,  9.60f , 113.93f ), Quaternion.Euler( new Vector3( -90,  0,  0 )), InteractiveObjects.ObjectType.Deposit_Plastic_Bag ); break;
			case 11: location = new DepositPosition( new Vector3( - 89.85f ,  8.66f ,  87.05f ), Quaternion.Euler( new Vector3( -90, 60,  0 )), InteractiveObjects.ObjectType.Deposit_Plastic_Bag ); break;
			case 12: location = new DepositPosition( new Vector3(   30.93f ,  9.05f , 105.72f ), Quaternion.Euler( new Vector3(   0,  0,  0 )), InteractiveObjects.ObjectType.Deposit_Flower_Vase_3 ); break;
			case 13: location = new DepositPosition( new Vector3( -141.50f ,  8.58f , 181.02f ), Quaternion.Euler( new Vector3(   0,  0,  0 )), InteractiveObjects.ObjectType.Deposit_Pet_Plastic_Bottle_2 ); break;
			/*
			case  0: location = new DepositPosition( new Vector3( -80f , 8.87f , 80.2f ), Quaternion.Euler( new Vector3(270,0,0 )), InteractiveObjects.ObjectType.Deposit_Bucket_Green ); break;
			case  1: location = new DepositPosition( new Vector3( -78f , 8.87f , 80.2f ), Quaternion.Euler( new Vector3(270,0,0 )), InteractiveObjects.ObjectType.Deposit_Bucket_Green ); break;
			case  2: location = new DepositPosition( new Vector3( -76f , 8.87f , 80.2f ), Quaternion.Euler( new Vector3(270,0,0 )), InteractiveObjects.ObjectType.Deposit_Bucket_Green ); break;
			case  3: location = new DepositPosition( new Vector3( -74f , 8.87f , 80.2f ), Quaternion.Euler( new Vector3(270,0,0 )), InteractiveObjects.ObjectType.Deposit_Bucket_Green ); break;
			case  4: location = new DepositPosition( new Vector3( -72f , 8.87f , 80.2f ), Quaternion.Euler( new Vector3(270,0,0 )), InteractiveObjects.ObjectType.Deposit_Bucket_Green ); break;
			case  5: location = new DepositPosition( new Vector3( -70f , 8.87f , 80.2f ), Quaternion.Euler( new Vector3(270,0,0 )), InteractiveObjects.ObjectType.Deposit_Bucket_Green ); break;
			case  6: location = new DepositPosition( new Vector3( -68f , 8.87f , 80.2f ), Quaternion.Euler( new Vector3(270,0,0 )), InteractiveObjects.ObjectType.Deposit_Bucket_Green ); break;
			case  7: location = new DepositPosition( new Vector3( -66f , 8.87f , 80.2f ), Quaternion.Euler( new Vector3(270,0,0 )), InteractiveObjects.ObjectType.Deposit_Bucket_Green ); break;
			case  8: location = new DepositPosition( new Vector3( -64f , 8.87f , 80.2f ), Quaternion.Euler( new Vector3(270,0,0 )), InteractiveObjects.ObjectType.Deposit_Bucket_Green ); break;
			case  9: location = new DepositPosition( new Vector3( -62f , 8.87f , 80.2f ), Quaternion.Euler( new Vector3(270,0,0 )), InteractiveObjects.ObjectType.Deposit_Bucket_Green ); break;
			case 10: location = new DepositPosition( new Vector3( -60f , 8.87f , 80.2f ), Quaternion.Euler( new Vector3(270,0,0 )), InteractiveObjects.ObjectType.Deposit_Bucket_Green ); break;
			case 11: location = new DepositPosition( new Vector3( -58f , 8.87f , 80.2f ), Quaternion.Euler( new Vector3(270,0,0 )), InteractiveObjects.ObjectType.Deposit_Bucket_Green ); break;
			case 12: location = new DepositPosition( new Vector3( -56f , 8.87f , 80.2f ), Quaternion.Euler( new Vector3(270,0,0 )), InteractiveObjects.ObjectType.Deposit_Bucket_Green ); break;
			case 13: location = new DepositPosition( new Vector3( -54f , 8.87f , 80.2f ), Quaternion.Euler( new Vector3(270,0,0 )), InteractiveObjects.ObjectType.Deposit_Bucket_Green ); break;
			*/
			}
			break;
			
		case 2: // Second period
			switch(id){
			case  0: location = new DepositPosition( new Vector3( 234.71f ,  9.95f ,  34.20f ), Quaternion.Euler( new Vector3( -90,  0,  0 )), InteractiveObjects.ObjectType.Deposit_Plastic_Cup ); break;
			case  1: location = new DepositPosition( new Vector3( 188.86f ,  9.31f ,  31.40f ), Quaternion.Euler( new Vector3(   0,  0,  0 )), InteractiveObjects.ObjectType.Deposit_Pet_Plastic_Bottle_1 ); break;
			case  2: location = new DepositPosition( new Vector3( 200.32f , 16.57f , -37.65f ), Quaternion.Euler( new Vector3( -90,  0,  0 )), InteractiveObjects.ObjectType.Deposit_Plastic_Bag ); break;
			case  3: location = new DepositPosition( new Vector3( 146.12f , 19.42f , -86.94f ), Quaternion.Euler( new Vector3(   0,  0,  0 )), InteractiveObjects.ObjectType.Deposit_Pet_Plastic_Bottle_2 ); break;
			case  4: location = new DepositPosition( new Vector3( 138.54f , 21.92f , -123.6f ), Quaternion.Euler( new Vector3( -90,205,  0 )), InteractiveObjects.ObjectType.Deposit_Plastic_Bag ); break;
			case  5: location = new DepositPosition( new Vector3(  99.41f , 20.58f , -199.5f ), Quaternion.Euler( new Vector3(  90,  0,  0 )), InteractiveObjects.ObjectType.Deposit_Tin_Can ); break;
			case  6: location = new DepositPosition( new Vector3( 130.78f , 21.35f , -250.7f ), Quaternion.Euler( new Vector3(   4,  0,  0 )), InteractiveObjects.ObjectType.Deposit_Tire ); break;
			case  7: location = new DepositPosition( new Vector3( 223.14f , 17.09f , -193.1f ), Quaternion.Euler( new Vector3( 10.4f, 1.0f ,-2.0f )), InteractiveObjects.ObjectType.Deposit_Tin_Can ); break;
			case  8: location = new DepositPosition( new Vector3( 279.93f , 16.24f , -186.0f ), Quaternion.Euler( new Vector3(-80.54f,-33.38f,-2.35f )), InteractiveObjects.ObjectType.Deposit_Plastic_Cup ); break;
			case  9: location = new DepositPosition( new Vector3( 295.73f , 16.79f , -116.9f ), Quaternion.Euler( new Vector3(   0,  0,  0 )), InteractiveObjects.ObjectType.Deposit_Pet_Plastic_Bottle_1 ); break;
			case 10: location = new DepositPosition( new Vector3( 410.33f , 20.30f , -175.1f ), Quaternion.Euler( new Vector3(2.42f,-1.09f,-175.1f )), InteractiveObjects.ObjectType.Deposit_Tire ); break;
			case 11: location = new DepositPosition( new Vector3( 436.28f , 15.75f ,  -13.1f ), Quaternion.Euler( new Vector3( -90,  0,  0 )), InteractiveObjects.ObjectType.Deposit_Plastic_Cup ); break;
			case 12: location = new DepositPosition( new Vector3( 435.85f , 16.20f ,  -26.8f ), Quaternion.Euler( new Vector3(   0,  0,  0 )), InteractiveObjects.ObjectType.Deposit_Tin_Can ); break;
			case 13: location = new DepositPosition( new Vector3( 471.26f ,  8.48f ,   29.1f ), Quaternion.Euler( new Vector3(   0,  0,-180 )), InteractiveObjects.ObjectType.Deposit_Tire ); break;
			case 14: location = new DepositPosition( new Vector3( 472.11f ,  9.08f , -109.1f ), Quaternion.Euler( new Vector3( -90,  0,  0 )), InteractiveObjects.ObjectType.Deposit_Plastic_Bag ); break;
			case 15: location = new DepositPosition( new Vector3( 449.05f , 16.72f , -290.5f ), Quaternion.Euler( new Vector3( -90,  0,  0 )), InteractiveObjects.ObjectType.Deposit_Plastic_Bag ); break;
			case 16: location = new DepositPosition( new Vector3( 484.66f , 21.11f , -327.9f ), Quaternion.Euler( new Vector3(   0,  0,  0 )), InteractiveObjects.ObjectType.Deposit_Pet_Plastic_Bottle_2 ); break;
			case 17: location = new DepositPosition( new Vector3( 382.45f , 21.62f , -233.3f ), Quaternion.Euler( new Vector3(-40.7f,-30.2f,78.0f )), InteractiveObjects.ObjectType.Deposit_Tin_Can ); break;
			case 18: location = new DepositPosition( new Vector3(   9.22f ,  8.36f ,  -29.8f ), Quaternion.Euler( new Vector3( -90,  0,  0 )), InteractiveObjects.ObjectType.Deposit_Plastic_Bag ); break;
			case 19: location = new DepositPosition( new Vector3( 327.13f ,  9.26f ,   54.6f ), Quaternion.Euler( new Vector3(   0,  0,  0 )), InteractiveObjects.ObjectType.Deposit_Pet_Plastic_Bottle_1 ); break;
			}
			break;
			
		case 3: // Third period
			switch(id){
			case  0: location = new DepositPosition( new Vector3( 263.32f , 28.29f , -441.1f ), Quaternion.Euler( new Vector3(-90,0,0 )), InteractiveObjects.ObjectType.Deposit_Bucket_Metal ); break;
			case  1: location = new DepositPosition( new Vector3( 239.81f , 33.36f , -515.4f ), Quaternion.Euler( new Vector3(-90,0,0 )), InteractiveObjects.ObjectType.Deposit_Bucket_Red ); break;
			case  2: location = new DepositPosition( new Vector3(-126.30f , 35.46f , -479.9f ), Quaternion.Euler( new Vector3(-90,0,0 )), InteractiveObjects.ObjectType.Deposit_Bucket_Green ); break;
			case  3: location = new DepositPosition( new Vector3( 265.04f , 33.99f , -492.5f ), Quaternion.Euler( new Vector3(0,0,0 )), InteractiveObjects.ObjectType.Deposit_Flower_Vase_1 ); break;
			case  4: location = new DepositPosition( new Vector3( 124.41f , 39.09f , -519.9f ), Quaternion.Euler( new Vector3(0,0,0 )), InteractiveObjects.ObjectType.Deposit_Flower_Vase_1 ); break;
			case  5: location = new DepositPosition( new Vector3( 199.79f , 28.93f , -462.8f ), Quaternion.Euler( new Vector3(0,0,0 )), InteractiveObjects.ObjectType.Deposit_Flower_Vase_1 ); break;
			case  6: location = new DepositPosition( new Vector3(- 89.53f , 35.01f , -502.0f ), Quaternion.Euler( new Vector3(0,0,0 )), InteractiveObjects.ObjectType.Deposit_Flower_Vase_2 ); break;
			case  7: location = new DepositPosition( new Vector3( 261.87f , 34.25f , -530.8f ), Quaternion.Euler( new Vector3(0,0,0 )), InteractiveObjects.ObjectType.Deposit_Flower_Vase_2 ); break;
			case  8: location = new DepositPosition( new Vector3( 208.77f , 29.21f , -462.3f ), Quaternion.Euler( new Vector3(0,0,0 )), InteractiveObjects.ObjectType.Deposit_Flower_Vase_2 ); break;
			case  9: location = new DepositPosition( new Vector3( -99.11f , 35.61f , -495.2f ), Quaternion.Euler( new Vector3(0,0,0 )), InteractiveObjects.ObjectType.Deposit_Flower_Vase_3 ); break;
			case 10: location = new DepositPosition( new Vector3( -72.40f , 35.97f , -496.2f ), Quaternion.Euler( new Vector3(0,0,0 )), InteractiveObjects.ObjectType.Deposit_Flower_Vase_3 ); break;
			case 11: location = new DepositPosition( new Vector3( 228.27f , 33.97f , -520.8f ), Quaternion.Euler( new Vector3(0,0,0 )), InteractiveObjects.ObjectType.Deposit_Flower_Vase_3 ); break;
			case 12: location = new DepositPosition( new Vector3( 171.29f , 29.16f , -459.2f ), Quaternion.Euler( new Vector3(0,0,0 )), InteractiveObjects.ObjectType.Deposit_Flower_Vase_3 ); break;
			case 13: location = new DepositPosition( new Vector3( 233.97f , 34.16f , -497.9f ), Quaternion.Euler( new Vector3(0,0,0 )), InteractiveObjects.ObjectType.Deposit_Flower_Vase_4 ); break;
			case 14: location = new DepositPosition( new Vector3( 248.72f , 28.96f , -455.3f ), Quaternion.Euler( new Vector3(0,0,0 )), InteractiveObjects.ObjectType.Deposit_Flower_Vase_4 ); break;
			case 15: location = new DepositPosition( new Vector3( 207.59f , 43.24f , -619.1f ), Quaternion.Euler( new Vector3(0,0,0 )), InteractiveObjects.ObjectType.Deposit_Pet_Plastic_Bottle_1 ); break;
			case 16: location = new DepositPosition( new Vector3( 238.60f , 43.32f , -595.5f ), Quaternion.Euler( new Vector3(0,0,0 )), InteractiveObjects.ObjectType.Deposit_Pet_Plastic_Bottle_2 ); break;
			case 17: location = new DepositPosition( new Vector3(  13.26f , 37.00f , -484.3f ), Quaternion.Euler( new Vector3(0,0,0 )), InteractiveObjects.ObjectType.Deposit_Flower_Vase_1 ); break;
			case 18: location = new DepositPosition( new Vector3( 210.38f , 34.24f , -514.6f ), Quaternion.Euler( new Vector3(-90,93,0 )), InteractiveObjects.ObjectType.Deposit_Grave_Big_Black ); break;
			case 19: location = new DepositPosition( new Vector3( 271.55f , 34.21f , -526.6f ), Quaternion.Euler( new Vector3(-90,-17,0 )), InteractiveObjects.ObjectType.Deposit_Grave_Small_Yellow ); break;
			case 20: location = new DepositPosition( new Vector3( 229.20f , 29.41f , -442.6f ), Quaternion.Euler( new Vector3(-90,89,0 )), InteractiveObjects.ObjectType.Deposit_Grave_Big_Marble5 ); break;
			case 21: location = new DepositPosition( new Vector3(  45.04f , 38.22f , -481.2f ), Quaternion.Euler( new Vector3(-90,90,0 )), InteractiveObjects.ObjectType.Deposit_Grave_Big_Marble3 ); break;
			case 22: location = new DepositPosition( new Vector3( 248.09f , 29.18f , -437.9f ), Quaternion.Euler( new Vector3(-90,0,0 )), InteractiveObjects.ObjectType.Deposit_Grave_Small_Black ); break;
			case 23: location = new DepositPosition( new Vector3( -74.89f , 36.19f , -502.6f ), Quaternion.Euler( new Vector3(-90,0,0 )), InteractiveObjects.ObjectType.Deposit_Grave_Small_Black ); break;
			case 24: location = new DepositPosition( new Vector3( 196.20f , 29.72f , -440.5f ), Quaternion.Euler( new Vector3(-90,0,0 )), InteractiveObjects.ObjectType.Deposit_Grave_Small_Yellow ); break;
			case 25: location = new DepositPosition( new Vector3( -76.83f , 36.21f , -496.3f ), Quaternion.Euler( new Vector3(-90,0,0 )), InteractiveObjects.ObjectType.Deposit_Grave_Small_Marble5 ); break;
			case 26: location = new DepositPosition( new Vector3( 232.10f , 34.22f , -515.8f ), Quaternion.Euler( new Vector3(-90,0,0 )), InteractiveObjects.ObjectType.Deposit_Grave_Small_Marble3 ); break;
			}
			break;
			
		case 4: // Fourth period
			switch(id){
			case  0: location = new DepositPosition( new Vector3( -120.20f ,  9.35f , -240.2f ), Quaternion.Euler( new Vector3( 270,0,0 )), InteractiveObjects.ObjectType.Deposit_Plastic_Cup ); break;
			case  1: location = new DepositPosition( new Vector3( -138.40f , 11.39f , -274.8f ), Quaternion.Euler( new Vector3( -40.7f,-30.2f,78.0f )), InteractiveObjects.ObjectType.Deposit_Tin_Can ); break;
			case  2: location = new DepositPosition( new Vector3( - 22.14f , 17.15f , -313.7f ), Quaternion.Euler( new Vector3( 270,0,0 )), InteractiveObjects.ObjectType.Deposit_Plastic_Bag ); break;
			case  3: location = new DepositPosition( new Vector3( -148.60f ,  9.49f , -121.5f ), Quaternion.Euler( new Vector3(  0,0,0 )), InteractiveObjects.ObjectType.Deposit_Pet_Plastic_Bottle_2 ); break;
			case  4: location = new DepositPosition( new Vector3( - 60.61f ,  8.60f , - 28.1f ), Quaternion.Euler( new Vector3(  0,0,0 )), InteractiveObjects.ObjectType.Deposit_Pet_Plastic_Bottle_2 ); break;
			case  5: location = new DepositPosition( new Vector3( - 22.99f , 12.50f , -218.5f ), Quaternion.Euler( new Vector3(270,0,0 )), InteractiveObjects.ObjectType.Deposit_Plastic_Bag ); break;
			case  6: location = new DepositPosition( new Vector3( - 69.32f ,  9.17f , -155.3f ), Quaternion.Euler( new Vector3(  0,270,0 )), InteractiveObjects.ObjectType.Deposit_Pool ); break;
			case  7: location = new DepositPosition( new Vector3( - 40.99f ,  8.44f , - 38.8f ), Quaternion.Euler( new Vector3( 90,0,0 )), InteractiveObjects.ObjectType.Deposit_Tin_Can ); break;
			case  8: location = new DepositPosition( new Vector3( - 89.07f ,  9.31f , -246.8f ), Quaternion.Euler( new Vector3(  0,0,0 )), InteractiveObjects.ObjectType.Deposit_Tin_Can ); break;
			case  9: location = new DepositPosition( new Vector3( -148.47f ,  9.22f , -115.6f ), Quaternion.Euler( new Vector3(276,0,0 )), InteractiveObjects.ObjectType.Deposit_Bucket_Metal ); break;
			case 10: location = new DepositPosition( new Vector3( - 93.52f ,  8.89f , - 56.6f ), Quaternion.Euler( new Vector3( 56.2f,10.2f,-8.6f )), InteractiveObjects.ObjectType.Deposit_Tire ); break;
			case 11: location = new DepositPosition( new Vector3( -106.50f ,  8.56f , - 42.9f ), Quaternion.Euler( new Vector3(  0,0,0 )), InteractiveObjects.ObjectType.Deposit_Pet_Plastic_Bottle_1 ); break;
			case 12: location = new DepositPosition( new Vector3( -143.22f ,  9.17f , -138.4f ), Quaternion.Euler( new Vector3(  0,-90,0 )), InteractiveObjects.ObjectType.Deposit_Pool ); break;
			case 13: location = new DepositPosition( new Vector3( -115.90f , 10.44f , - 57.4f ), Quaternion.Euler( new Vector3(270,0,0 )), InteractiveObjects.ObjectType.Deposit_Plastic_Cup ); break;
			case 14: location = new DepositPosition( new Vector3( - 63.05f ,  9.36f , -130.2f ), Quaternion.Euler( new Vector3(-90,0,0 )), InteractiveObjects.ObjectType.Deposit_Bucket_Red ); break;
			case 15: location = new DepositPosition( new Vector3( - 22.53f ,  8.74f , - 74.2f ), Quaternion.Euler( new Vector3(-90,0,0 )), InteractiveObjects.ObjectType.Deposit_Plastic_Bag ); break;
			case 16: location = new DepositPosition( new Vector3( - 98.45f , 14.80f , - 65.3f ), Quaternion.Euler( new Vector3(-90,0,0 )), InteractiveObjects.ObjectType.Deposit_Plastic_Cup ); break;
			case 17: location = new DepositPosition( new Vector3( -177.80f ,  8.37f , -  4.9f ), Quaternion.Euler( new Vector3(-90,0,0 )), InteractiveObjects.ObjectType.Deposit_Plastic_Bag ); break;
			case 18: location = new DepositPosition( new Vector3( -138.50f ,  8.60f ,   29.9f ), Quaternion.Euler( new Vector3(  0,0,0 )), InteractiveObjects.ObjectType.Deposit_Pet_Plastic_Bottle_2 ); break;
			case 19: location = new DepositPosition( new Vector3( - 66.11f ,  9.56f ,   31.5f ), Quaternion.Euler( new Vector3(  0,0,0 )), InteractiveObjects.ObjectType.Deposit_Flower_Vase_4 ); break;
			case 20: location = new DepositPosition( new Vector3( -148.32f ,  8.35f ,   25.0f ), Quaternion.Euler( new Vector3(  0,0,0 )), InteractiveObjects.ObjectType.Deposit_Flower_Vase_2 ); break;
			case 21: location = new DepositPosition( new Vector3( -148.20f ,  9.00f ,   29.5f ), Quaternion.Euler( new Vector3(-9.7f,5.3f,-281.5f )), InteractiveObjects.ObjectType.Deposit_Tire ); break;
			case 22: location = new DepositPosition( new Vector3( - 67.61f ,  8.91f ,   32.9f ), Quaternion.Euler( new Vector3(  0,0,0 )), InteractiveObjects.ObjectType.Deposit_Barrel ); break;
			case 23: location = new DepositPosition( new Vector3( - 59.96f , 28.97f , -189.8f ), Quaternion.Euler( new Vector3(  0,0,0 )), InteractiveObjects.ObjectType.Deposit_Tin_Can ); break;
			case 24: location = new DepositPosition( new Vector3( - 68.70f , 23.44f , -187.0f ), Quaternion.Euler( new Vector3(  0,0,0 )), InteractiveObjects.ObjectType.Deposit_Flower_Vase_1 ); break;
			case 25: location = new DepositPosition( new Vector3( - 76.07f , 28.28f , -189.2f ), Quaternion.Euler( new Vector3(  0,0,0 )), InteractiveObjects.ObjectType.Deposit_Flower_Vase_2 ); break;
			case 26: location = new DepositPosition( new Vector3( - 76.93f , 27.96f , -199.2f ), Quaternion.Euler( new Vector3(  0,0,0 )), InteractiveObjects.ObjectType.Deposit_Flower_Vase_3 ); break;
			case 27: location = new DepositPosition( new Vector3( - 66.24f , 14.58f , -189.7f ), Quaternion.Euler( new Vector3(  0,0,0 )), InteractiveObjects.ObjectType.Deposit_Flower_Vase_3 ); break;
			case 28: location = new DepositPosition( new Vector3( - 62.45f , 13.70f , -198.7f ), Quaternion.Euler( new Vector3(  0,0,0 )), InteractiveObjects.ObjectType.Deposit_Flower_Vase_4 ); break;
			case 29: location = new DepositPosition( new Vector3( - 61.03f , 23.86f , -197.0f ), Quaternion.Euler( new Vector3(-90,0,0 )), InteractiveObjects.ObjectType.Deposit_Plastic_Cup ); break;
			}
			break;
		}

		return location;
	}




	//================================================================================================//
	//================================================================================================//
	/// <summary> Cointains the positions/orientation where 'curiosities' could be placed </summary>
	public ObjectPosition getCuriosityLocation(uint period, uint id){
		ObjectPosition location = new ObjectPosition( Vector3.zero, Quaternion.identity );
		
		switch( period ){
			
		case 1: // First period
			switch(id){
			case  0: location = new ObjectPosition( new Vector3( -139.6f ,  9.8f , 214.5f ), Quaternion.Euler( new Vector3( 1.5f, -180.9f,   0f )) ); break;
			case  1: location = new ObjectPosition( new Vector3( -100.9f ,  8.3f , 120.8f ), Quaternion.Euler( new Vector3( 1.5f, -180.0f,   0f )) ); break;
			case  2: location = new ObjectPosition( new Vector3( -193.2f , 10.3f , 210.5f ), Quaternion.Euler( new Vector3(   0f, -244.5f,-1.5f )) ); break;
			case  3: location = new ObjectPosition( new Vector3( - 89.1f ,  9.4f , 235.1f ), Quaternion.Euler( new Vector3( 1.5f, -166.5f,   0f )) ); break;
			case  4: location = new ObjectPosition( new Vector3( -137.4f ,  9.3f , 179.7f ), Quaternion.Euler( new Vector3(-1.2f,    0.5f,   0f )) ); break;
			case  5: location = new ObjectPosition( new Vector3(   46.9f ,  9.3f , 102.7f ), Quaternion.Euler( new Vector3(   0f, -129.8f, 1.5f )) ); break;
			case  6: location = new ObjectPosition( new Vector3(  -46.2f ,  9.4f , 145.0f ), Quaternion.Euler( new Vector3(   0f, -293.1f,-1.5f )) ); break;
			
			}
			break;
			
		case 2: // Second period
			switch(id){
			case  0: location = new ObjectPosition( new Vector3( 189.6f , 16.4f , -145.9f ), Quaternion.Euler( new Vector3(   0f, -270f  ,-1.5f )) ); break;
			case  1: location = new ObjectPosition( new Vector3( 111.3f , 26.2f , - 58.2f ), Quaternion.Euler( new Vector3( 1.5f, -198.6f,   0f )) ); break;
			case  2: location = new ObjectPosition( new Vector3(  66.5f , 10.2f ,    8.1f ), Quaternion.Euler( new Vector3(-1.5f, - 33.2f,   0f )) ); break;
			case  3: location = new ObjectPosition( new Vector3( 237.3f ,  9.8f ,   21.4f ), Quaternion.Euler( new Vector3(   0f, - 76.3f, 1.5f )) ); break;
			case  4: location = new ObjectPosition( new Vector3( 262.0f , 21.8f , - 61.7f ), Quaternion.Euler( new Vector3( 1.5f, -170.7f,   0f )) ); break;
			case  5: location = new ObjectPosition( new Vector3( 322.8f , 24.7f , - 38.0f ), Quaternion.Euler( new Vector3( 1.5f, -167.0f,   0f )) ); break;
			case  6: location = new ObjectPosition( new Vector3( 404.2f , 17.4f , -  6.5f ), Quaternion.Euler( new Vector3(   0f, -237.2f,-1.5f )) ); break;
			case  7: location = new ObjectPosition( new Vector3( 394.5f , 19.1f , -171.7f ), Quaternion.Euler( new Vector3( 1.5f, -145.1f,   0f )) ); break;
			case  8: location = new ObjectPosition( new Vector3( 424.3f , 17.8f , -290.8f ), Quaternion.Euler( new Vector3(-1.5f, -319.8f,-1.5f )) ); break;
			case  9: location = new ObjectPosition( new Vector3( 362.2f , 17.5f , -301.5f ), Quaternion.Euler( new Vector3(   0f, -264.8f,-1.5f )) ); break;
			case 10: location = new ObjectPosition( new Vector3( 204.6f , 21.6f , -252.5f ), Quaternion.Euler( new Vector3( 1.5f, -180.0f,   0f )) ); break;
			case 11: location = new ObjectPosition( new Vector3(  69.6f , 16.2f , -223.9f ), Quaternion.Euler( new Vector3(   0f, -268.3f,-1.5f )) ); break;
			}
			break;
			
		case 3: // Third period
			switch(id){
			case  0: location = new ObjectPosition( new Vector3( 121.8f , 23.3f , -413.3f ), Quaternion.Euler( new Vector3( -1.5f,   0.8f, 0.0f )) ); break;
			case  1: location = new ObjectPosition( new Vector3( 262.1f , 22.7f , -399.8f ), Quaternion.Euler( new Vector3( -1.5f, -29.1f, 0.0f )) ); break;
			case  2: location = new ObjectPosition( new Vector3( 272.6f , 29.2f , -451.2f ), Quaternion.Euler( new Vector3( -1.5f,-382.2f, 0.0f )) ); break;
			case  3: location = new ObjectPosition( new Vector3( 353.4f , 44.0f , -479.4f ), Quaternion.Euler( new Vector3(  0.0f,-111.7f, 1.5f )) ); break;
			case  4: location = new ObjectPosition( new Vector3( 160.5f , 43.2f , -602.9f ), Quaternion.Euler( new Vector3(  0.0f,-308.6f,-1.5f )) ); break;
			case  5: location = new ObjectPosition( new Vector3( 139.3f , 39.5f , -522.6f ), Quaternion.Euler( new Vector3(  1.5f,-344.3f, 0.0f )) ); break;
			case  6: location = new ObjectPosition( new Vector3( 128.9f , 29.1f , -446.1f ), Quaternion.Euler( new Vector3(  0.0f,-240.2f,-1.5f )) ); break;
			case  7: location = new ObjectPosition( new Vector3(  67.9f , 30.6f , -440.9f ), Quaternion.Euler( new Vector3(  1.5f,-170.8f, 0.0f )) ); break;
			case  8: location = new ObjectPosition( new Vector3(  25.5f , 37.8f , -467.2f ), Quaternion.Euler( new Vector3(  1.5f,-180.0f, 0.0f )) ); break;
			case  9: location = new ObjectPosition( new Vector3(  -0.3f , 37.9f , -486.8f ), Quaternion.Euler( new Vector3( -1.5f,  -6.3f, 0.0f )) ); break;
			case 10: location = new ObjectPosition( new Vector3(  37.1f , 47.8f , -571.9f ), Quaternion.Euler( new Vector3( -1.5f,  -9.3f, 0.0f )) ); break;
			case 11: location = new ObjectPosition( new Vector3( -96.5f , 36.0f , -556.9f ), Quaternion.Euler( new Vector3( -1.5f,   4.7f, 0.0f )) ); break;
			case 12: location = new ObjectPosition( new Vector3(-116.1f , 36.0f , -480.5f ), Quaternion.Euler( new Vector3(  1.5f,-180.0f, 0.0f )) ); break;
			case 13: location = new ObjectPosition( new Vector3(-162.8f , 35.8f , -477.2f ), Quaternion.Euler( new Vector3(  0.0f,-239.0f,-1.5f )) ); break;
			case 14: location = new ObjectPosition( new Vector3( -87.2f , 23.5f , -403.7f ), Quaternion.Euler( new Vector3( -1.5f,-321.4f, 0.0f )) ); break;
			case 15: location = new ObjectPosition( new Vector3( 206.7f , 34.0f , -522.0f ), Quaternion.Euler( new Vector3( -1.5f,-355.5f, 0.0f )) ); break;
			case 16: location = new ObjectPosition( new Vector3( 265.2f , 34.0f , -510.3f ), Quaternion.Euler( new Vector3(  1.5f,-180.0f, 0.0f )) ); break;
			}
			break;
			
		case 4: // Fourth period
			switch(id){
			case  0: location = new ObjectPosition( new Vector3( -168.9f ,  9.4f ,    7.7f ), Quaternion.Euler( new Vector3(   0f, -282.8f,   -1.5f )) ); break;
			case  1: location = new ObjectPosition( new Vector3( -120.9f ,  9.3f ,  -48.8f ), Quaternion.Euler( new Vector3(   0f,  -91.6f,    1.5f )) ); break;
			case  2: location = new ObjectPosition( new Vector3(  -96.1f , 15.6f ,  -45.2f ), Quaternion.Euler( new Vector3(   0f, -129.5f,    1.5f )) ); break;
			case  3: location = new ObjectPosition( new Vector3(  -58.8f ,  9.3f ,   28.3f ), Quaternion.Euler( new Vector3(   0f, -106.7f,    1.5f )) ); break;
			case  4: location = new ObjectPosition( new Vector3(  -40.3f ,  9.4f ,  -92.3f ), Quaternion.Euler( new Vector3(   0f,  -90.1f,    1.5f )) ); break;
			case  5: location = new ObjectPosition( new Vector3(  -63.5f , 10.0f , -125.9f ), Quaternion.Euler( new Vector3(   0f,  -29.9f,    0.0f )) ); break;
			case  6: location = new ObjectPosition( new Vector3(  -78.7f , 10.1f , -181.2f ), Quaternion.Euler( new Vector3(   0f,  -87.6f,    1.5f )) ); break;
			case  7: location = new ObjectPosition( new Vector3( -117.7f , 11.0f , -154.8f ), Quaternion.Euler( new Vector3(   0f, -229.4f,   -1.5f )) ); break;
			case  8: location = new ObjectPosition( new Vector3( -199.2f , 10.2f , -112.3f ), Quaternion.Euler( new Vector3(   0f, -299.2f,   -1.5f )) ); break;
			case  9: location = new ObjectPosition( new Vector3(  -67.8f , 10.1f , -244.5f ), Quaternion.Euler( new Vector3(   0f,  -91.6f,    1.5f )) ); break;
			case 10: location = new ObjectPosition( new Vector3( -134.9f , 19.3f , -302.7f ), Quaternion.Euler( new Vector3(   0f, -264.7f,   -1.5f )) ); break;
			case 11: location = new ObjectPosition( new Vector3( -206.7f , 10.0f , -176.5f ), Quaternion.Euler( new Vector3(   0f, -238.4f,   -1.5f )) ); break;
			case 12: location = new ObjectPosition( new Vector3(  -63.2f , 10.2f , -198.5f ), Quaternion.Euler( new Vector3(-1.2f, -  6.3f,      0f )) ); break;
			case 13: location = new ObjectPosition( new Vector3(  -76.6f , 14.8f , -189.9f ), Quaternion.Euler( new Vector3(   0f, -270.1f,   -1.5f )) ); break;
			case 14: location = new ObjectPosition( new Vector3(  -68.3f , 19.6f , -185.0f ), Quaternion.Euler( new Vector3( 1.5f,  131.5f,   -1.5f )) ); break;
			case 15: location = new ObjectPosition( new Vector3(  -61.9f , 19.3f , -197.1f ), Quaternion.Euler( new Vector3(-1.5f,    0.0f,    0.0f )) ); break;
			case 16: location = new ObjectPosition( new Vector3(  -70.0f , 23.9f , -198.9f ), Quaternion.Euler( new Vector3( 1.5f,   90.0f,    0.0f )) ); break;
			case 17: location = new ObjectPosition( new Vector3(  -68.7f , 23.6f , -188.5f ), Quaternion.Euler( new Vector3( 0.0f,   90.0f,   -1.5f )) ); break;
			case 18: location = new ObjectPosition( new Vector3(  -71.1f , 28.2f , -191.9f ), Quaternion.Euler( new Vector3(-1.5f,    0.0f,    0.0f )) ); break;
			case 19: location = new ObjectPosition( new Vector3(  -61.2f , 28.5f , -188.7f ), Quaternion.Euler( new Vector3( 1.5f, -180.0f,    0.0f )) ); break;
			case 20: location = new ObjectPosition( new Vector3(  -52.3f , 10.5f , -131.5f ), Quaternion.Euler( new Vector3( 1.5f, -180.0f,    0.0f )) ); break;
			case 21: location = new ObjectPosition( new Vector3(  -24.3f , 10.5f ,   41.6f ), Quaternion.Euler( new Vector3(-1.5f,   37.0f,    0.0f )) ); break;
			case 22: location = new ObjectPosition( new Vector3(  -97.0f ,  8.7f ,  -16.0f ), Quaternion.Euler( new Vector3( 0.0f,  202.2f,    1.5f )) ); break;
			case 23: location = new ObjectPosition( new Vector3(  -85.8f , 10.1f , -206.2f ), Quaternion.Euler( new Vector3( 1.5f, -180.0f,    0.0f )) ); break;
			}
			break;
		}
		
		return location;
	}


}
